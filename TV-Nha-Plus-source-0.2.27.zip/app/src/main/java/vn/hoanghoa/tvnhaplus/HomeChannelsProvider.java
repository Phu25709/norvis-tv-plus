package vn.hoanghoa.tvnhaplus;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.Locale;
import java.net.HttpURLConnection;
import java.net.URL;

/** Shares only four Home shortcut labels and opaque channel IDs with the LEAP-S1 launcher. */
public final class HomeChannelsProvider extends ContentProvider {
    public static final String AUTHORITY = "vn.hoanghoa.tvnhaplus.homechannels";
    private static final String HOME_PACKAGE = "com.gathin.tvhome";
    private static final String SHORTCUT_PACKAGE = "vn.hoanghoa.tvnhaplus";
    private static final long MAX_LOGO_BYTES = 2L * 1024L * 1024L;
    private static final String[] COLUMNS = {"id", "name", "number", "package", "activity", "logo_uri"};

    @Override public boolean onCreate() { return true; }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        MatrixCursor result = new MatrixCursor(COLUMNS);
        if (!"list".equals(uri.getLastPathSegment()) || getContext() == null || !calledByHome()) return result;
        File store = new File(getContext().getFilesDir(), "playlist-v1.json");
        if (!store.isFile()) return result;
        try {
            JSONObject saved = new JSONObject(new String(Files.readAllBytes(store.toPath()), StandardCharsets.UTF_8));
            JSONArray channels = saved.optJSONArray("channels");
            if (channels == null) return result;

            JSONObject vtv1 = null;
            JSONObject vtv3 = null;
            JSONObject vtv6 = null;
            String liveGroup = null;
            String entertainmentGroup = null;
            for (int i = 0; i < channels.length(); i++) {
                JSONObject channel = channels.optJSONObject(i);
                if (channel == null) continue;
                String name = channel.optString("name", "").trim();
                String group = channel.optString("groupTitle", "").trim();
                if (vtv1 == null && channelMatches(name, "VTV1")) vtv1 = channel;
                if (vtv3 == null && channelMatches(name, "VTV3")) vtv3 = channel;
                if (vtv6 == null && channelMatches(name, "VTV6")) vtv6 = channel;
                String foldedGroup = group.toLowerCase(Locale.ROOT);
                if (liveGroup == null && foldedGroup.contains("live events")) liveGroup = group;
                if (entertainmentGroup == null && foldedGroup.contains("giải trí")) entertainmentGroup = group;
            }

            addChannel(result, vtv1, "vn.hoanghoa.tvnhaplus.shortcut.Vtv1HomeActivity");
            addChannel(result, vtv3, "vn.hoanghoa.tvnhaplus.shortcut.Vtv3HomeActivity");
            addChannel(result, vtv6, "vn.hoanghoa.tvnhaplus.shortcut.Vtv6HomeActivity");
            if (liveGroup != null) addGroup(result, "home-live-events", "Live sự kiện", 0,
                    "vn.hoanghoa.tvnhaplus.shortcut.LiveEventsHomeActivity");
            if (entertainmentGroup != null) addGroup(result, "home-entertainment", "Giải Trí", 0,
                    "vn.hoanghoa.tvnhaplus.shortcut.EntertainmentHomeActivity");
        } catch (Exception ignored) {
            // A missing or mid-update playlist simply leaves the Home channel strip on its fallback source.
        }
        return result;
    }

    private boolean calledByHome() {
        String[] packages = getContext().getPackageManager().getPackagesForUid(android.os.Binder.getCallingUid());
        if (packages != null) for (String name : packages) if (HOME_PACKAGE.equals(name)) return true;
        return false;
    }

    private static boolean channelMatches(String name, String number) {
        return name.equalsIgnoreCase(number) || name.toLowerCase(Locale.ROOT)
                .startsWith(number.toLowerCase(Locale.ROOT) + " ");
    }

    private static void addChannel(MatrixCursor cursor, JSONObject channel, String activity) {
        if (channel == null) return;
        Uri logo = Uri.withAppendedPath(Uri.parse("content://" + AUTHORITY + "/logo"), channel.optString("id"));
        cursor.addRow(new Object[]{channel.optString("id"), channel.optString("name"),
                channel.optInt("channelNumber"), SHORTCUT_PACKAGE, activity,
                channel.optString("logoUrl", "").trim().isEmpty() ? "" : logo.toString()});
    }

    private static void addGroup(MatrixCursor cursor, String id, String label, int number, String activity) {
        cursor.addRow(new Object[]{id, label, number, SHORTCUT_PACKAGE, activity, ""});
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode) || getContext() == null || !calledByHome())
            throw new FileNotFoundException("Home logo unavailable");
        if (uri.getPathSegments().size() != 2 || !"logo".equals(uri.getPathSegments().get(0)))
            throw new FileNotFoundException("Home logo unavailable");
        String channelId = uri.getLastPathSegment();
        String logoUrl = findLogoUrl(channelId);
        if (logoUrl == null || !(logoUrl.startsWith("https://") || logoUrl.startsWith("http://")))
            throw new FileNotFoundException("Home logo unavailable");

        File cacheDirectory = new File(getContext().getFilesDir(), "home-channel-logos");
        if (!cacheDirectory.isDirectory() && !cacheDirectory.mkdirs()) throw new FileNotFoundException("Home logo unavailable");
        File cached = new File(cacheDirectory, digest(logoUrl) + ".img");
        if (!cached.isFile() || cached.length() <= 0) {
            try { downloadLogo(logoUrl, cached); }
            catch (IOException ignored) { throw new FileNotFoundException("Home logo unavailable"); }
        }
        return ParcelFileDescriptor.open(cached, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    private String findLogoUrl(String channelId) throws FileNotFoundException {
        try {
            File store = new File(getContext().getFilesDir(), "playlist-v1.json");
            JSONObject saved = new JSONObject(new String(Files.readAllBytes(store.toPath()), StandardCharsets.UTF_8));
            JSONArray channels = saved.optJSONArray("channels");
            if (channels == null) return null;
            for (int i = 0; i < channels.length(); i++) {
                JSONObject channel = channels.optJSONObject(i);
                if (channel != null && channelId.equals(channel.optString("id"))) return channel.optString("logoUrl", "").trim();
            }
            return null;
        } catch (Exception ignored) {
            throw new FileNotFoundException("Home logo unavailable");
        }
    }

    private static void downloadLogo(String address, File destination) throws IOException {
        HttpURLConnection connection = null;
        File temporary = new File(destination.getPath() + ".tmp");
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "TVNhaPlus/0.2 AndroidTV");
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("Logo request failed");
            if (connection.getContentLengthLong() > MAX_LOGO_BYTES) throw new IOException("Logo too large");
            try (InputStream input = connection.getInputStream(); FileOutputStream output = new FileOutputStream(temporary)) {
                byte[] buffer = new byte[8192];
                long total = 0;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    total += count;
                    if (total > MAX_LOGO_BYTES) throw new IOException("Logo too large");
                    output.write(buffer, 0, count);
                }
                output.getFD().sync();
            }
            if (temporary.length() <= 0) throw new IOException("Empty logo");
            try {
                Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception moveError) {
                Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            if (connection != null) connection.disconnect();
            if (temporary.exists()) temporary.delete();
        }
    }

    private static String digest(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) result.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return result.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }

    @Override public String getType(Uri uri) {
        return uri.getPathSegments().size() == 2 && "logo".equals(uri.getPathSegments().get(0))
                ? "image/*" : "vnd.android.cursor.dir/vnd.tvnhaplus.homechannel";
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
}
