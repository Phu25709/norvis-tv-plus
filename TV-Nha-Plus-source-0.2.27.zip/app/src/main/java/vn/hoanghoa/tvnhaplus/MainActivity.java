package vn.hoanghoa.tvnhaplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import vn.hoanghoa.tvnhaplus.data.Channel;
import vn.hoanghoa.tvnhaplus.data.Playlist;
import vn.hoanghoa.tvnhaplus.data.PlaylistRepository;
import vn.hoanghoa.tvnhaplus.ui.LaunchSplashView;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 15, 22);
    private static final int MUTED = Color.rgb(151, 163, 177);
    private static final int GOLD = Color.rgb(217, 180, 102);
    private static final long MIN_SPLASH_MS = 550L;
    private LinearLayout page;
    private PlaylistRepository repository;
    private boolean playerLaunched;
    private long splashStartedAt;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        repository = ((TvNhaPlusApp) getApplication()).playlistRepository();
        splashStartedAt = SystemClock.elapsedRealtime();
        showStartupSplash();
        repository.loadAsync(saved -> {
            if (playerLaunched || isFinishing()) return;
            if (saved == null || saved.channels.isEmpty()) {
                afterSplash(this::buildHome);
                return;
            }
            playerLaunched = true;
            afterSplash(() -> openPlayer(repository.lastChannelId()));
        });
    }

    private void showStartupSplash() {
        setContentView(new LaunchSplashView(this));
    }

    private void afterSplash(Runnable action) {
        long elapsed = SystemClock.elapsedRealtime() - splashStartedAt;
        long delay = Math.max(0L, MIN_SPLASH_MS - elapsed);
        getWindow().getDecorView().postDelayed(() -> {
            if (!isFinishing()) action.run();
        }, delay);
    }

    private void buildHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setPadding(dp(48), dp(20), dp(48), dp(18));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(13, 20, 29), BG, Color.rgb(15, 22, 30)}));

        LinearLayout rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setPadding(0, dp(8), dp(28), 0);
        root.addView(rail, new LinearLayout.LayoutParams(dp(256), -1));
        TextView brand = label("TV NHÀ", 17, GOLD);
        brand.setLetterSpacing(.2f);
        rail.addView(brand, new LinearLayout.LayoutParams(-1, dp(44)));
        TextView plus = label("PLUS", 12, MUTED);
        plus.setLetterSpacing(.24f);
        rail.addView(plus, new LinearLayout.LayoutParams(-1, dp(30)));
        View divider = new View(this);
        divider.setBackgroundColor(0x332B3948);
        LinearLayout.LayoutParams divLp = new LinearLayout.LayoutParams(-1, dp(1));
        divLp.topMargin = dp(6);
        divLp.bottomMargin = dp(14);
        rail.addView(divider, divLp);
        Button home = navButton("⌂     Trang chủ", true, () -> buildHome());
        rail.addView(home);
        Button guide = navButton("▤     TV Guide", false, () -> showMessage("TV Guide", "Thêm playlist M3U để mở danh sách kênh."));
        rail.addView(guide);
        Button favorites = navButton("☆     Yêu thích", false, () -> showMessage("Yêu thích", "Kênh bạn lưu sẽ hiện ở đây."));
        rail.addView(favorites);
        View spacer = new View(this);
        rail.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));
        Button settings = navButton("⚙     Cài đặt", false, () -> showMessage("Cài đặt", "Cài đặt playlist sẽ có trong bản tiếp theo."));
        rail.addView(settings);

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        root.addView(page, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(44)));
        TextView greeting = label("TRUYỀN HÌNH CỦA GIA ĐÌNH", 13, MUTED);
        greeting.setLetterSpacing(.12f);
        header.addView(greeting, new LinearLayout.LayoutParams(0, -2, 1));
        TextView clock = label("IPTV  ·  ANDROID TV", 12, 0xFF728093);
        clock.setLetterSpacing(.08f);
        header.addView(clock);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(30), dp(20), dp(24), dp(20));
        hero.setBackground(roundRect(new int[]{0xFF1C2B39, 0xFF15212C, 0xFF17212B}, 0xFF354554, dp(22)));
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, dp(292));
        heroLp.topMargin = dp(8);
        page.addView(hero, heroLp);
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        hero.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        TextView eyebrow = label("XEM TRUYỀN HÌNH", 13, GOLD);
        eyebrow.setLetterSpacing(.14f);
        copy.addView(eyebrow);
        TextView headline = label("Mở lên là xem.", 34, Color.WHITE);
        headline.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        LinearLayout.LayoutParams headlineLp = new LinearLayout.LayoutParams(-1, -2);
        headlineLp.topMargin = dp(7);
        copy.addView(headline, headlineLp);
        TextView body = label("Danh sách kênh, lịch phát và điều khiển\nđược thiết kế riêng cho màn hình TV.", 16, 0xFFBAC5D0);
        body.setLineSpacing(dp(7), 1f);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(-1, -2);
        bodyLp.topMargin = dp(6);
        copy.addView(body, bodyLp);
        Button add = actionButton("＋   Thêm playlist M3U", true, this::showImportDialog);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(dp(270), dp(50));
        addLp.topMargin = dp(13);
        copy.addView(add, addLp);
        TextView format = label("Hỗ trợ link M3U qua HTTP hoặc HTTPS", 14, 0xFF8E9EAE);
        LinearLayout.LayoutParams formatLp = new LinearLayout.LayoutParams(-1, -2);
        formatLp.topMargin = dp(6);
        copy.addView(format, formatLp);

        LinearLayout art = new LinearLayout(this);
        art.setGravity(Gravity.CENTER);
        art.setBackground(roundRect(new int[]{0xFF253747, 0xFF1B2C3B}, 0xFF536576, dp(24)));
        TextView mark = label("TV", 58, 0xFFE7D4A8);
        mark.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        mark.setGravity(Gravity.CENTER);
        art.addView(mark, new LinearLayout.LayoutParams(dp(176), dp(160)));
        LinearLayout.LayoutParams artLp = new LinearLayout.LayoutParams(dp(190), dp(190));
        artLp.leftMargin = dp(18);
        hero.addView(art, artLp);

        LinearLayout section = new LinearLayout(this);
        section.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, dp(42));
        sectionLp.topMargin = dp(6);
        page.addView(section, sectionLp);
        TextView sectionTitle = label("BẮT ĐẦU NHANH", 13, 0xFFAFBAC6);
        sectionTitle.setLetterSpacing(.12f);
        section.addView(sectionTitle, new LinearLayout.LayoutParams(0, -2, 1));
        TextView note = label("Đơn giản, rõ ràng, dễ dùng", 14, 0xFF788797);
        section.addView(note);

        LinearLayout cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(cards, new LinearLayout.LayoutParams(-1, dp(106)));
        cards.addView(infoCard("01", "Thêm playlist", "Dán link M3U của bạn", () -> showImportDialog()), weightedCard());
        cards.addView(infoCard("02", "Mở TV Guide", "Chọn kênh bằng remote", () -> showMessage("TV Guide", "Thêm playlist M3U để mở danh sách kênh.")), weightedCardWithGap());
        cards.addView(infoCard("03", "Tiếp tục xem", "Nhớ kênh bạn xem gần nhất", () -> showMessage("Tiếp tục xem", "Kênh gần nhất sẽ được lưu trên thiết bị.")), weightedCardWithGap());

        TextView footer = label("← → Di chuyển     OK Chọn     BACK Quay lại", 13, 0xFF657486);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, dp(28));
        footerLp.topMargin = dp(6);
        page.addView(footer, footerLp);
        setContentView(root);
        add.requestFocus();
    }

    private LinearLayout infoCard(String number, String title, String body, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(11), dp(16), dp(10));
        card.setFocusable(true);
        card.setClickable(true);
        card.setBackground(roundRect(new int[]{0xFF141D27, 0xFF131B24}, 0xFF293744, dp(16)));
        card.setOnClickListener(v -> action.run());
        TextView index = label(number, 12, GOLD);
        card.addView(index);
        TextView titleView = label(title, 18, Color.WHITE);
        titleView.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(5);
        card.addView(titleView, titleLp);
        TextView bodyView = label(body, 14, MUTED);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(-1, -2);
        bodyLp.topMargin = dp(3);
        card.addView(bodyView, bodyLp);
        return card;
    }

    private Button navButton(String text, boolean selected, Runnable action) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        button.setPadding(dp(16), 0, dp(12), 0);
        button.setTextColor(selected ? Color.WHITE : 0xFF9BA8B6);
        button.setBackground(roundRect(selected ? new int[]{0xFF273847, 0xFF21313F} : new int[]{0x00141D27, 0x00141D27}, selected ? 0xFF3B5061 : 0xFF354657, dp(12)));
        button.setFocusable(true);
        button.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.bottomMargin = dp(7);
        button.setLayoutParams(lp);
        return button;
    }

    private Button actionButton(String text, boolean primary, Runnable action) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(17);
        button.setTypeface(null, Typeface.BOLD);
        button.setTextColor(primary ? Color.rgb(19, 24, 29) : Color.WHITE);
        button.setBackground(roundRect(primary ? new int[]{0xFFE4C681, 0xFFD7B368} : new int[]{0xFF253442, 0xFF1B2834}, primary ? 0xFFF3D998 : 0xFF465B6C, dp(14)));
        button.setFocusable(true);
        button.setOnClickListener(v -> action.run());
        return button;
    }

    private void showImportDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF98A5B1);
        input.setHint("https://example.com/playlist.m3u");
        input.setTextSize(18);
        input.setSelectAllOnFocus(true);
        input.setText("https://tinyurl.com/vmt47");
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Thêm playlist M3U")
                .setMessage("Dán đường dẫn playlist của bạn")
                .setView(input)
                .setNegativeButton("Để sau", (d, w) -> d.dismiss())
                .setPositiveButton("Tải danh sách", null).create();
        dialog.setOnShowListener(d -> {
            input.requestFocus();
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String address = input.getText().toString().trim();
                if (address.isEmpty()) {
                    input.setError("Hãy nhập link M3U");
                    return;
                }
                dialog.dismiss();
                showImportProgress(address);
            });
        });
        dialog.show();
        input.requestFocus();
    }

    private void showImportProgress(String address) {
        LinearLayout progressBox = new LinearLayout(this);
        progressBox.setGravity(Gravity.CENTER_VERTICAL);
        progressBox.setPadding(dp(24), dp(8), dp(24), dp(18));
        android.widget.ProgressBar progress = new android.widget.ProgressBar(this);
        progressBox.addView(progress, new LinearLayout.LayoutParams(dp(30), dp(30)));
        TextView message = label("  Đang tải và đọc playlist…", 17, Color.WHITE);
        progressBox.addView(message);
        AlertDialog loading = new AlertDialog.Builder(this).setTitle("Đang tải kênh").setView(progressBox).setCancelable(false).create();
        loading.show();
        repository.importFromUrl(address, (playlist, error) -> {
            loading.dismiss();
            if (error != null) {
                String detail = error.getMessage() == null ? "Không đọc được playlist." : error.getMessage();
                showMessage("Chưa tải được playlist", detail + "\n\nKiểm tra link và kết nối mạng rồi thử lại.");
                return;
            }
            Channel first = playlist.channels.get(0);
            openPlayer(first.id);
        });
    }

    private void openPlayer(String channelId) {
        android.content.Intent intent = new android.content.Intent(this, PlayerActivity.class);
        if (channelId != null && !channelId.isEmpty()) intent.putExtra(PlayerActivity.EXTRA_CHANNEL_ID, channelId);
        intent.putExtra(PlayerActivity.EXTRA_SHOW_SPLASH, true);
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Đóng", (d, w) -> d.dismiss()).show();
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private GradientDrawable roundRect(int[] colors, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams weightedCard() { return new LinearLayout.LayoutParams(0, -1, 1); }
    private LinearLayout.LayoutParams weightedCardWithGap() {
        LinearLayout.LayoutParams lp = weightedCard();
        lp.leftMargin = dp(12);
        return lp;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
