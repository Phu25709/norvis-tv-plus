package vn.hoanghoa.tvnhaplus;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.media3.common.Player;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import vn.hoanghoa.tvnhaplus.data.Channel;
import vn.hoanghoa.tvnhaplus.data.EpgRepository;
import vn.hoanghoa.tvnhaplus.data.Playlist;
import vn.hoanghoa.tvnhaplus.data.PlaylistRepository;
import vn.hoanghoa.tvnhaplus.player.PlayerController;
import vn.hoanghoa.tvnhaplus.ui.GuideView;
import vn.hoanghoa.tvnhaplus.ui.LaunchSplashView;

public final class PlayerActivity extends Activity {
    public static final String EXTRA_CHANNEL_ID = "channel_id";
    public static final String EXTRA_GUIDE_GROUP = "guide_group";
    public static final String EXTRA_SHOW_SPLASH = "show_startup_splash";
    private static final long PLAYLIST_REFRESH_INTERVAL_MS = 30L * 60L * 1000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final StringBuilder numericEntry = new StringBuilder();
    private final Runnable commitNumber = this::tuneNumber;
    private final Runnable hideStatus = this::hideStatusNow;
    private final Runnable refreshPlaylistIfDue = this::refreshPlaylistIfDue;
    private PlaylistRepository repository;
    private EpgRepository epgRepository;
    private Map<String, vn.hoanghoa.tvnhaplus.data.XmltvParser.Schedule> schedules = java.util.Collections.emptyMap();
    private Playlist playlist;
    private PlayerController player;
    private Channel pendingStart;
    private PlayerView playerView;
    private FrameLayout root;
    private LinearLayout statusBar;
    private TextView channelNumber;
    private TextView channelName;
    private TextView technicalInfo;
    private TextView statusText;
    private TextView numberHud;
    private AlertDialog playbackErrorDialog;
    private LaunchSplashView startupSplash;
    private GuideView guide;
    private Channel current;
    private boolean guideVisible;
    private boolean favoriteLongPressHandled;
    private boolean autoRefreshActive;
    private boolean playlistRefreshInProgress;
    private String pendingGuideGroup = "";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (getIntent().getBooleanExtra(EXTRA_SHOW_SPLASH, false)) showStartupSplash();
        repository = ((TvNhaPlusApp) getApplication()).playlistRepository();
        repository.loadAsync(this::startAfterPlaylistLoad);
    }

    private void startAfterPlaylistLoad(Playlist saved) {
        if (isFinishing()) return;
        playlist = saved;
        if (playlist == null || playlist.channels.isEmpty()) { finish(); return; }
        pendingGuideGroup = getIntent().getStringExtra(EXTRA_GUIDE_GROUP);
        if (pendingGuideGroup == null) pendingGuideGroup = "";
        schedulePlaylistRefresh();
        String requested = getIntent().getStringExtra(EXTRA_CHANNEL_ID);
        if (requested == null || requested.isEmpty()) requested = repository.lastChannelId();
        pendingStart = findById(requested);
        if (pendingStart == null) pendingStart = playlist.channels.get(0);
        buildPlayer();
        root.post(() -> {
            if (isFinishing()) return;
            epgRepository = new EpgRepository(this);
            epgRepository.refreshIfNeeded(playlist, values -> {
                schedules = values;
                if (guide != null) guide.updateSchedules(values);
            });
            initializePlayer();
            if (!pendingGuideGroup.isEmpty()) openGuide();
            root.postDelayed(this::checkForUpdate, 1800L);
        });
    }

    private void checkForUpdate() {
        if (isFinishing() || isDestroyed()) return;
        UpdateChecker.check(update -> {
            if (isFinishing() || isDestroyed()) return;
            String version = update.versionName.isEmpty() ? "mới" : update.versionName;
            String message = "Đã có TV Nhà Plus " + version + ".";
            if (!update.notes.isEmpty()) message += "\n\n" + update.notes;
            new AlertDialog.Builder(this)
                    .setTitle("Có bản cập nhật mới")
                    .setMessage(message)
                    .setNegativeButton("Để sau", null)
                    .setPositiveButton("Cập nhật", (dialog, which) -> {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(update.apkUrl))); }
                        catch (Exception ignored) { }
                    })
                    .show();
        });
    }

    private void buildPlayer() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setFocusable(false);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        statusBar = new LinearLayout(this);
        statusBar.setOrientation(LinearLayout.HORIZONTAL);
        statusBar.setGravity(Gravity.CENTER_VERTICAL);
        statusBar.setPadding(dp(30), dp(18), dp(34), dp(26));
        statusBar.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xED080D12, 0xB9080D12, 0x00080D12}));
        LinearLayout channelBox = new LinearLayout(this);
        channelBox.setOrientation(LinearLayout.VERTICAL);
        statusBar.addView(channelBox, new LinearLayout.LayoutParams(0, -2, 1));
        channelNumber = text("", 14, 0xFFD8B66E);
        channelNumber.setTypeface(null, Typeface.BOLD);
        channelBox.addView(channelNumber);
        channelName = text("", 26, Color.WHITE);
        channelName.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, -2);
        nameLp.topMargin = dp(4);
        channelBox.addView(channelName, nameLp);
        technicalInfo = text("Đang đọc tín hiệu video/audio…", 14, 0xFFD3DDE6);
        technicalInfo.setSingleLine(true);
        technicalInfo.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams technicalLp = new LinearLayout.LayoutParams(-1, -2);
        technicalLp.topMargin = dp(4);
        channelBox.addView(technicalInfo, technicalLp);
        statusText = text("ĐANG PHÁT", 13, 0xFFB7C4D0);
        statusBar.addView(statusText);
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(-1, dp(130), Gravity.BOTTOM);
        root.addView(statusBar, statusLp);
        LinearLayout clockBadge = new LinearLayout(this);
        clockBadge.setGravity(Gravity.CENTER);
        clockBadge.setPadding(dp(6), 0, dp(6), 0);
        clockBadge.setBackground(round(0x66131D26, 0x333E5160, dp(10)));
        clockBadge.setFocusable(false);
        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFF0F3F6);
        clock.setTextSize(20);
        clock.setTypeface(null, Typeface.BOLD);
        clock.setGravity(Gravity.CENTER);
        clock.setContentDescription("Giờ hiện tại");
        clockBadge.addView(clock, new LinearLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams clockLp = new FrameLayout.LayoutParams(dp(76), dp(34), Gravity.TOP | Gravity.RIGHT);
        clockLp.topMargin = dp(24);
        clockLp.rightMargin = dp(24);
        root.addView(clockBadge, clockLp);
        numberHud = text("", 28, Color.WHITE);
        numberHud.setTypeface(null, Typeface.BOLD);
        numberHud.setGravity(Gravity.CENTER);
        numberHud.setPadding(dp(22), dp(10), dp(22), dp(10));
        numberHud.setBackground(round(0xE61B2732, 0xFFE0BE73, dp(14)));
        numberHud.setVisibility(View.GONE);
        FrameLayout.LayoutParams numberLp = new FrameLayout.LayoutParams(dp(250), dp(66), Gravity.TOP | Gravity.RIGHT);
        numberLp.setMargins(0, dp(38), dp(42), 0);
        root.addView(numberHud, numberLp);
        if (startupSplash != null) {
            ViewGroup parent = (ViewGroup) startupSplash.getParent();
            if (parent != null) parent.removeView(startupSplash);
            root.addView(startupSplash, new FrameLayout.LayoutParams(-1, -1));
        }
        setContentView(root);
        root.setFocusable(true);
        root.requestFocus();
        statusText.setText("ĐANG MỞ KÊNH…");
        statusBar.setVisibility(View.VISIBLE);
    }

    private void initializePlayer() {
        if (player != null || isFinishing()) return;
        player = new PlayerController(this, playerView, new PlayerController.Listener() {
            @Override public void onChannelChanged(Channel channel) { updateChannel(channel); }
            @Override public void onPlaybackError(String message) {
                hideStartupSplash();
                if (guideVisible) dismissPlaybackErrorDialog();
                else showPlaybackError(message);
            }
            @Override public void onRenderedFirstFrame() { hideStartupSplash(); }
            @Override public void onTechnicalInfo(String summary) {
                technicalInfo.setText(summary);
                showStatus("ĐANG PHÁT");
            }
            @Override public void onPlaybackState(int state) {
                if (state == Player.STATE_BUFFERING) showStatus("ĐANG TẢI LUỒNG…");
                else if (state == Player.STATE_READY) showStatus("ĐANG PHÁT");
            }
        });
        Channel start = pendingStart;
        pendingStart = null;
        if (start != null) play(start);
    }

    private void play(Channel channel) {
        if (player == null) { pendingStart = channel; return; }
        current = channel;
        repository.setLastChannel(channel.id);
        player.play(channel);
        if (guide != null) guide.refreshFavorites(repository.favorites());
        showStatus("ĐANG PHÁT");
    }

    private void openGuide() {
        if (guideVisible || playlist.channels.isEmpty()) return;
        if (guide == null) {
            guide = new GuideView(this, playlist, repository.favorites(), new GuideView.Listener() {
                @Override public void onChannelSelected(Channel channel) {
                    closeGuide();
                    play(channel);
                }
                @Override public void onFavoriteToggled(Channel channel) {
                    repository.toggleFavorite(channel.id);
                    guide.refreshFavorites(repository.favorites());
                }
                @Override public void onChannelFocused(Channel channel) { }
                @Override public void onChangePlaylist() { showChangePlaylistDialog(); }
                @Override public void onAudioOptions() { showAudioOptions(); }
                @Override public void onSubtitleOptions() { showSubtitleOptions(); }
            });
            root.addView(guide, new FrameLayout.LayoutParams(-1, -1));
        } else {
            guide.setVisibility(View.VISIBLE);
            guide.bringToFront();
        }
        guideVisible = true;
        guide.updateSchedules(schedules);
            guide.show(current == null ? "" : current.id, pendingGuideGroup);
            pendingGuideGroup = "";
    }

    private void closeGuide() {
        if (!guideVisible || guide == null) return;
        guideVisible = false;
        guide.setVisibility(View.GONE);
        root.requestFocus();
        showStatus("ĐANG PHÁT");
    }

    private void schedulePlaylistRefresh() {
        handler.removeCallbacks(refreshPlaylistIfDue);
        if (!autoRefreshActive || playlist == null || playlist.sourceUrl.isEmpty()) return;
        long elapsed = System.currentTimeMillis() - repository.lastSuccessfulPlaylistRefreshMillis();
        long delay = Math.max(0L, PLAYLIST_REFRESH_INTERVAL_MS - Math.max(0L, elapsed));
        handler.postDelayed(refreshPlaylistIfDue, delay);
    }

    private void refreshPlaylistIfDue() {
        if (!autoRefreshActive || isFinishing() || playlist == null || playlist.sourceUrl.isEmpty()) return;
        long elapsed = System.currentTimeMillis() - repository.lastSuccessfulPlaylistRefreshMillis();
        if (elapsed < PLAYLIST_REFRESH_INTERVAL_MS) {
            schedulePlaylistRefresh();
            return;
        }
        if (playlistRefreshInProgress) {
            handler.postDelayed(refreshPlaylistIfDue, 60_000L);
            return;
        }
        playlistRefreshInProgress = true;
        String sourceUrl = playlist.sourceUrl;
        repository.importFromUrl(sourceUrl, (replacement, error) -> {
            playlistRefreshInProgress = false;
            if (error == null && replacement != null) {
                if (!isFinishing() && autoRefreshActive) applyAutomaticPlaylistUpdate(replacement);
                schedulePlaylistRefresh();
            } else if (autoRefreshActive) {
                handler.postDelayed(refreshPlaylistIfDue, 5L * 60L * 1000L);
            }
        });
    }

    private void applyAutomaticPlaylistUpdate(Playlist replacement) {
        boolean reopenGuide = guideVisible;
        Channel previous = current;
        Channel updated = PlaylistRepository.findMatchingChannel(replacement, previous);
        if (updated == null) {
            updated = findById(replacement, repository.lastChannelId());
            if (updated == null) updated = replacement.channels.get(0);
        }

        if (guide != null) root.removeView(guide);
        guide = null;
        guideVisible = false;
        playlist = replacement;
        current = updated;
        repository.setLastChannel(updated.id);

        boolean streamChanged = previous == null || !previous.streamUrl.equals(updated.streamUrl);
        if (streamChanged) player.play(updated);
        else player.updateCurrentChannelMetadata(updated);

        epgRepository.refreshIfNeeded(replacement, values -> {
            schedules = values;
            if (guide != null) guide.updateSchedules(values);
        });
        if (reopenGuide) openGuide();
    }

    private static Channel findById(Playlist source, String id) {
        if (source == null || id == null || id.isEmpty()) return null;
        for (Channel channel : source.channels) if (channel.id.equals(id)) return channel;
        return null;
    }

    private void showChangePlaylistDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF91A0AF);
        input.setHint("https://example.com/playlist.m3u");
        input.setTextSize(18);
        input.setText(playlist.sourceUrl);
        input.setSelectAllOnFocus(true);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Đổi playlist M3U")
                .setMessage("Playlist mới sẽ thay danh sách đang dùng")
                .setView(input)
                .setNegativeButton("Huỷ", (d, w) -> d.dismiss())
                .setPositiveButton("Tải danh sách", null).create();
        dialog.setOnShowListener(ignored -> {
            input.requestFocus();
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String address = input.getText().toString().trim();
                if (address.isEmpty()) { input.setError("Hãy nhập link M3U"); return; }
                dialog.dismiss();
                LinearLayout box = new LinearLayout(this);
                box.setGravity(Gravity.CENTER_VERTICAL);
                box.setPadding(dp(24), dp(8), dp(24), dp(18));
                box.addView(new android.widget.ProgressBar(this), new LinearLayout.LayoutParams(dp(30), dp(30)));
                box.addView(text("  Đang tải danh sách mới…", 17, Color.WHITE));
                AlertDialog loading = new AlertDialog.Builder(this).setTitle("Đang tải kênh").setView(box).setCancelable(false).create();
                loading.show();
                repository.importFromUrl(address, (replacement, error) -> {
                    loading.dismiss();
                    if (error != null) {
                        new AlertDialog.Builder(this).setTitle("Chưa tải được playlist")
                                .setMessage(error.getMessage() == null ? "Kiểm tra đường dẫn và kết nối mạng." : error.getMessage())
                                .setPositiveButton("Đóng", (d, w) -> d.dismiss()).show();
                        return;
                    }
                    guideVisible = false;
                    root.removeView(guide);
                    guide = null;
                    playlist = replacement;
                    Channel resume = findById(repository.lastChannelId());
                    if (resume == null) resume = playlist.channels.get(0);
                    epgRepository.refreshIfNeeded(playlist, values -> {
                        schedules = values;
                        if (guide != null) guide.updateSchedules(values);
                    });
                    play(resume);
                    openGuide();
                });
            });
        });
        dialog.show();
        input.requestFocus();
    }

    private void showAudioOptions() {
        if (player == null) return;
        List<PlayerController.AudioTrackOption> tracks = player.audioTracks();
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(8), dp(20), dp(12));
        TextView note = text(surroundOutputNote(), 15, 0xFFCFD8E1);
        note.setLineSpacing(dp(3), 1f);
        content.addView(note, new LinearLayout.LayoutParams(-1, -2));
        if (tracks.isEmpty()) {
            TextView unavailable = text("Luồng hiện tại chưa cung cấp danh sách track âm thanh.", 16, 0xFFD9B76F);
            LinearLayout.LayoutParams unavailableLp = new LinearLayout.LayoutParams(-1, -2);
            unavailableLp.topMargin = dp(14);
            content.addView(unavailable, unavailableLp);
        } else {
            ScrollView scroll = new ScrollView(this);
            scroll.setVerticalScrollBarEnabled(false);
            LinearLayout options = new LinearLayout(this);
            options.setOrientation(LinearLayout.VERTICAL);
            scroll.addView(options);
            final AlertDialog[] dialogRef = new AlertDialog[1];
            Button automatic = audioOptionButton("Tự động chọn track" + (tracks.stream().noneMatch(t -> t.selected) ? "" : "  ✓"));
            automatic.setOnClickListener(v -> {
                player.useAutomaticAudioTrackSelection();
                if (dialogRef[0] != null) dialogRef[0].dismiss();
            });
            options.addView(automatic, audioOptionLayout());
            for (PlayerController.AudioTrackOption track : tracks) {
                Button choice = audioOptionButton(track.label + (track.selected ? "  ✓" : ""));
                choice.setOnClickListener(v -> {
                    player.selectAudioTrack(track);
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                });
                options.addView(choice, audioOptionLayout());
            }
            LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(-1, dp(Math.min(300, 58 * (tracks.size() + 1))));
            scrollLp.topMargin = dp(14);
            content.addView(scroll, scrollLp);
            AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Âm thanh").setView(content)
                    .setNegativeButton("Đóng", (value, which) -> value.dismiss()).create();
            dialogRef[0] = dialog;
            dialog.show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Âm thanh").setView(content)
                .setNegativeButton("Đóng", (dialog, which) -> dialog.dismiss()).show();
    }

    private void showSubtitleOptions() {
        if (player == null) return;
        List<PlayerController.SubtitleTrackOption> tracks = player.subtitleTracks();
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(8), dp(20), dp(12));
        TextView note = text("Phụ đề phụ thuộc track được nhúng trong luồng; hiện app chưa nhập file phụ đề ngoài.", 15, 0xFFCFD8E1);
        note.setLineSpacing(dp(3), 1f);
        content.addView(note, new LinearLayout.LayoutParams(-1, -2));
        if (tracks.isEmpty()) {
            TextView unavailable = text("Luồng hiện tại chưa cung cấp track phụ đề.", 16, 0xFFD9B76F);
            LinearLayout.LayoutParams unavailableLp = new LinearLayout.LayoutParams(-1, -2);
            unavailableLp.topMargin = dp(14);
            content.addView(unavailable, unavailableLp);
        }
        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout options = new LinearLayout(this);
        options.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(options);
        final AlertDialog[] dialogRef = new AlertDialog[1];
        Button automatic = audioOptionButton("Tự động chọn phụ đề");
        automatic.setOnClickListener(v -> {
            player.useAutomaticSubtitleSelection();
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        options.addView(automatic, audioOptionLayout());
        Button disabled = audioOptionButton("Tắt phụ đề");
        disabled.setOnClickListener(v -> {
            player.disableSubtitles();
            if (dialogRef[0] != null) dialogRef[0].dismiss();
        });
        options.addView(disabled, audioOptionLayout());
        for (PlayerController.SubtitleTrackOption track : tracks) {
            Button choice = audioOptionButton(track.label + (track.selected ? "  ✓" : ""));
            choice.setOnClickListener(v -> {
                player.selectSubtitleTrack(track);
                if (dialogRef[0] != null) dialogRef[0].dismiss();
            });
            options.addView(choice, audioOptionLayout());
        }
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(-1, dp(Math.min(300, 58 * (tracks.size() + 2))));
        scrollLp.topMargin = dp(14);
        content.addView(scroll, scrollLp);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Phụ đề").setView(content)
                .setNegativeButton("Đóng", (value, which) -> value.dismiss()).create();
        dialogRef[0] = dialog;
        dialog.show();
    }

    private Button audioOptionButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        button.setPadding(dp(14), 0, dp(12), 0);
        button.setFocusable(true);
        button.setBackground(round(0xFF1B2833, 0xFF405364, dp(12)));
        return button;
    }

    private LinearLayout.LayoutParams audioOptionLayout() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(52));
        params.bottomMargin = dp(7);
        return params;
    }

    private String surroundOutputNote() {
        int mode = android.provider.Settings.Global.getInt(getContentResolver(), "encoded_surround_output", 0);
        String system;
        if (mode == 1) system = "LEAP-S1 hiện đang tắt đầu ra âm thanh vòm.";
        else if (mode == 2) system = "LEAP-S1 đang cho phép đầu ra âm thanh vòm.";
        else if (mode == 3) system = "LEAP-S1 đang dùng danh sách định dạng âm thanh vòm tùy chọn.";
        else system = "LEAP-S1 đang tự động chọn định dạng âm thanh vòm.";
        return "Có thể chọn track Dolby/5.1 nếu kênh cung cấp. Âm thanh vòm qua HDMI còn cần TV/receiver hỗ trợ và cài đặt đầu ra phù hợp.\n\n" + system;
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (guideVisible) {
            if (keyCode == KeyEvent.KEYCODE_BACK) { closeGuide(); return true; }
            return super.onKeyDown(keyCode, event);
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) return super.onKeyDown(keyCode, event);
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            openGuide();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_CHANNEL_UP) { zap(1); return true; }
        if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN || keyCode == KeyEvent.KEYCODE_CHANNEL_DOWN) { zap(-1); return true; }
        int digit = digitForKey(keyCode);
        if (digit >= 0) {
            if (event.getRepeatCount() == 0) acceptDigit(digit);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void seekBy(long offsetMillis) {
        if (player != null && player.seekBy(offsetMillis)) {
            String message = offsetMillis < 0 ? "TUA LÙI 10 GIÂY" : "TUA TỚI 10 GIÂY";
            handler.postDelayed(() -> showStatus(message), 300);
        } else {
            showStatus("Kênh live này không hỗ trợ tua");
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        int keyCode = event.getKeyCode();
        if (!guideVisible && event.getAction() == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_MEDIA_REWIND) {
                seekBy(-10_000L);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) {
                seekBy(10_000L);
                return true;
            }
        }
        boolean confirm = keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER;
        boolean longPress = event.getRepeatCount() > 0 || event.isLongPress();
        if (guideVisible && confirm && event.getAction() == KeyEvent.ACTION_DOWN && longPress) {
            if (!favoriteLongPressHandled) {
                Channel selected = guide == null ? null : guide.focusedChannel();
                if (selected != null) {
                    repository.toggleFavorite(selected.id);
                    guide.refreshFavorites(repository.favorites());
                    favoriteLongPressHandled = true;
                }
            }
            if (favoriteLongPressHandled) return true;
        }
        if (guideVisible && confirm && event.getAction() == KeyEvent.ACTION_UP && favoriteLongPressHandled) {
            favoriteLongPressHandled = false;
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        if (guideVisible) closeGuide();
        else super.onBackPressed();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra(EXTRA_SHOW_SPLASH, false)) showStartupSplash();
        else hideStartupSplash();
        String group = intent.getStringExtra(EXTRA_GUIDE_GROUP);
        String channelId = intent.getStringExtra(EXTRA_CHANNEL_ID);
        if (player == null) {
            pendingGuideGroup = group == null ? "" : group;
            if (playlist != null && channelId != null) pendingStart = findById(channelId);
            return;
        }
        if (group != null && !group.trim().isEmpty()) {
            dismissPlaybackErrorDialog();
            pendingGuideGroup = group;
            if (guideVisible && guide != null) {
                guide.show(current == null ? "" : current.id, pendingGuideGroup);
                pendingGuideGroup = "";
            } else {
                openGuide();
            }
            return;
        }
        Channel channel = findById(playlist, channelId);
        if (channel != null) {
            if (guideVisible) closeGuide();
            play(channel);
        }
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (player != null) player.release();
        super.onDestroy();
    }

    @Override protected void onStart() {
        super.onStart();
        autoRefreshActive = true;
        Playlist latest = repository.playlist();
        if (playlist != null && latest != null && latest != playlist) applyAutomaticPlaylistUpdate(latest);
        if (player != null) player.resume();
        schedulePlaylistRefresh();
    }

    @Override protected void onStop() {
        autoRefreshActive = false;
        handler.removeCallbacks(refreshPlaylistIfDue);
        if (player != null) player.pause();
        super.onStop();
    }

    private void zap(int step) {
        if (playlist.channels.isEmpty()) return;
        int index = current == null ? -1 : playlist.channels.indexOf(current);
        index = (index + step + playlist.channels.size()) % playlist.channels.size();
        play(playlist.channels.get(index));
    }

    private void acceptDigit(int digit) {
        if (numericEntry.length() >= 3) numericEntry.setLength(0);
        numericEntry.append(digit);
        numberHud.setText(numericEntry.toString());
        numberHud.setVisibility(View.VISIBLE);
        numberHud.setAlpha(1f);
        handler.removeCallbacks(commitNumber);
        if (numericEntry.length() == 3) handler.postDelayed(commitNumber, 250);
        else handler.postDelayed(commitNumber, 1300);
    }

    private void tuneNumber() {
        if (numericEntry.length() == 0) return;
        int number;
        try { number = Integer.parseInt(numericEntry.toString()); }
        catch (NumberFormatException ignored) { numericEntry.setLength(0); return; }
        numericEntry.setLength(0);
        Channel match = null;
        for (Channel channel : playlist.channels) if (channel.channelNumber == number) { match = channel; break; }
        handler.removeCallbacks(hideStatus);
        if (match != null) {
            numberHud.setText(String.format(java.util.Locale.ROOT, "%03d   %s", match.channelNumber, match.name));
            play(match);
        } else {
            numberHud.setText(String.format(java.util.Locale.ROOT, "%03d   Không có kênh", number));
        }
        handler.postDelayed(() -> numberHud.setVisibility(View.GONE), 2300);
    }

    private int digitForKey(int keyCode) {
        if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9) return keyCode - KeyEvent.KEYCODE_0;
        return -1;
    }

    private void updateChannel(Channel channel) {
        channelNumber.setText(String.format(java.util.Locale.ROOT, "%03d", channel.channelNumber));
        channelName.setText(channel.name);
        showStatus("ĐANG PHÁT");
    }

    private void showStatus(String text) {
        if (statusText == null || guideVisible) return;
        statusText.setText(text);
        statusBar.setVisibility(View.VISIBLE);
        statusBar.setAlpha(1f);
        handler.removeCallbacks(hideStatus);
        handler.postDelayed(hideStatus, 4500);
    }

    private void showStartupSplash() {
        if (startupSplash == null) startupSplash = new LaunchSplashView(this);
        ViewGroup parent = startupSplash.getParent() instanceof ViewGroup ? (ViewGroup) startupSplash.getParent() : null;
        if (parent != null) parent.removeView(startupSplash);
        startupSplash.setAlpha(1f);
        startupSplash.setVisibility(View.VISIBLE);
        if (root == null) setContentView(startupSplash);
        else root.addView(startupSplash, new FrameLayout.LayoutParams(-1, -1));
    }

    private void hideStartupSplash() {
        if (startupSplash == null) return;
        LaunchSplashView splash = startupSplash;
        startupSplash = null;
        splash.animate().alpha(0f).setDuration(180).withEndAction(() -> {
            if (splash.getParent() instanceof ViewGroup) ((ViewGroup) splash.getParent()).removeView(splash);
        }).start();
    }

    private void hideStatusNow() {
        if (statusBar == null) return;
        statusBar.animate().alpha(0f).setDuration(250)
                .withEndAction(() -> statusBar.setVisibility(View.GONE)).start();
    }

    private void showPlaybackError(String message) {
        statusText.setText("KHÔNG PHÁT ĐƯỢC");
        dismissPlaybackErrorDialog();
        playbackErrorDialog = new AlertDialog.Builder(this)
                .setTitle("Kênh chưa phát được")
                .setMessage("Có thể link đã hết hạn hoặc mạng đang chậm.\n\n" + message)
                .setNegativeButton("Đóng", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Thử lại", (dialog, which) -> { if (current != null) play(current); })
                .create();
        playbackErrorDialog.setOnDismissListener(dialog -> playbackErrorDialog = null);
        playbackErrorDialog.show();
    }

    private void dismissPlaybackErrorDialog() {
        if (playbackErrorDialog != null && playbackErrorDialog.isShowing()) playbackErrorDialog.dismiss();
        playbackErrorDialog = null;
    }

    private Channel findById(String id) {
        if (id == null) return null;
        for (Channel channel : playlist.channels) if (channel.id.equals(id)) return channel;
        return null;
    }

    private TextView text(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }
    private GradientDrawable round(int color, int stroke, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
