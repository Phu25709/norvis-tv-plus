package vn.hoanghoa.tvnhaplus;

import android.app.Application;

import vn.hoanghoa.tvnhaplus.data.PlaylistRepository;

public final class TvNhaPlusApp extends Application {
    private PlaylistRepository playlistRepository;

    @Override public void onCreate() {
        super.onCreate();
        playlistRepository = new PlaylistRepository(this);
    }

    public PlaylistRepository playlistRepository() { return playlistRepository; }
}
