package vn.hoanghoa.tvnhaplus;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Checks a small public JSON manifest without blocking playback or startup. */
public final class UpdateChecker {
    // Keep this in sync with app/build.gradle when cutting a release.
    private static final int CURRENT_VERSION_CODE = 29;
    private static final String MANIFEST_URL =
            "https://raw.githubusercontent.com/Phu25709/tv-nha-plus/main/update.json";

    public static final class UpdateInfo {
        public final int versionCode;
        public final String versionName;
        public final String apkUrl;
        public final String notes;
        UpdateInfo(int versionCode, String versionName, String apkUrl, String notes) {
            this.versionCode = versionCode;
            this.versionName = versionName;
            this.apkUrl = apkUrl;
            this.notes = notes;
        }
    }

    public interface Callback { void onUpdate(UpdateInfo update); }

    private UpdateChecker() { }

    public static void check(Callback callback) {
        new Thread(() -> {
            UpdateInfo found = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(MANIFEST_URL).openConnection();
                connection.setConnectTimeout(2500);
                connection.setReadTimeout(2500);
                connection.setRequestProperty("Accept", "application/json");
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                            connection.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) body.append(line);
                    }
                    JSONObject json = new JSONObject(body.toString());
                    int code = json.optInt("versionCode", 0);
                    String apk = json.optString("apkUrl", "");
                    if (code > CURRENT_VERSION_CODE && !apk.isEmpty()) {
                        found = new UpdateInfo(code, json.optString("versionName", ""), apk,
                                json.optString("notes", ""));
                    }
                }
            } catch (Exception ignored) {
                // Update checks are best effort and must never interrupt TV playback.
            } finally {
                if (connection != null) connection.disconnect();
            }
            UpdateInfo result = found;
            if (result != null) new Handler(Looper.getMainLooper()).post(() -> callback.onUpdate(result));
        }, "tvplus-update-check").start();
    }
}
