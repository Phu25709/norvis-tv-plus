package vn.hoanghoa.tvnhaplus.data;

import org.json.JSONObject;

public final class Channel {
    public final String id;
    public final String name;
    public final String streamUrl;
    public final String logoUrl;
    public final String groupTitle;
    public final String tvgId;
    public final int channelNumber;

    public Channel(String id, String name, String streamUrl, String logoUrl,
                   String groupTitle, String tvgId, int channelNumber) {
        this.id = id;
        this.name = name;
        this.streamUrl = streamUrl;
        this.logoUrl = logoUrl;
        this.groupTitle = groupTitle;
        this.tvgId = tvgId;
        this.channelNumber = channelNumber;
    }

    JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("id", id);
            json.put("name", name);
            json.put("streamUrl", streamUrl);
            json.put("logoUrl", logoUrl);
            json.put("groupTitle", groupTitle);
            json.put("tvgId", tvgId);
            json.put("channelNumber", channelNumber);
        } catch (Exception ignored) {}
        return json;
    }

    static Channel fromJson(JSONObject json) {
        return new Channel(json.optString("id"), json.optString("name"),
                json.optString("streamUrl"), json.optString("logoUrl"),
                json.optString("groupTitle"), json.optString("tvgId"),
                json.optInt("channelNumber"));
    }
}
