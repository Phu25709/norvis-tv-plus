package vn.hoanghoa.tvnhaplus.data;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class ChannelNumbering {
    private ChannelNumbering() {}

    static List<Channel> orderedAndNumbered(List<Channel> source) {
        ArrayList<Channel> ordered = new ArrayList<>(source);
        ordered.sort((left, right) -> Integer.compare(tier(left), tier(right)));
        ArrayList<Channel> numbered = new ArrayList<>(ordered.size());
        for (int i = 0; i < ordered.size(); i++) {
            Channel channel = ordered.get(i);
            numbered.add(new Channel(channel.id, channel.name, channel.streamUrl, channel.logoUrl,
                    channel.groupTitle, channel.tvgId, i + 1));
        }
        return numbered;
    }

    private static int tier(Channel channel) {
        String group = plain(channel.groupTitle);
        String value = group + " " + plain(channel.name);
        if (group.equals("kenh vtv") || group.matches(".*\\bvtv\\b.*")) return 0;
        if (containsAny(value, "su kien", "event", "ppv", "pay per view")) return 2;
        if (containsAny(value, "nuoc ngoai", "quoc te", "international", "foreign")) return 4;
        if (containsAny(group, "dia phuong", "trong nuoc", "kenh htv", "kenh htvc", "thiet yeu", "kenh vov")) return 1;
        return 3;
    }

    private static String plain(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
    }

    private static boolean containsAny(String value, String... tokens) {
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }
}
