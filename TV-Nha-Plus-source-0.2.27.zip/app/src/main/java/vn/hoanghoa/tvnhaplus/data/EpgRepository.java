package vn.hoanghoa.tvnhaplus.data;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class EpgRepository {
    public interface Callback { void onLoaded(Map<String, XmltvParser.Schedule> schedules); }
    private static final long REFRESH_MILLIS = 30 * 60 * 1000L;
    private static final long MAX_XML_BYTES = 64L * 1024L * 1024L;
    private final Context appContext;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final File cacheFile;
    private final Map<String, XmltvParser.Schedule> cache = new HashMap<>();
    private String cachedUrl = "";
    private long checkedAt;
    private boolean loading;

    public EpgRepository(Context context) {
        appContext = context.getApplicationContext();
        cacheFile = new File(appContext.getFilesDir(), "epg-cache-v1.json");
        readCache();
    }

    public synchronized XmltvParser.Schedule get(String channelId) { return cache.get(channelId); }

    public synchronized void refreshIfNeeded(Playlist playlist, Callback callback) {
        if (playlist == null || playlist.epgUrl.trim().isEmpty()) {
            main.post(() -> callback.onLoaded(snapshot()));
            return;
        }
        if (loading) {
            main.post(() -> callback.onLoaded(snapshot()));
            return;
        }
        if (playlist.epgUrl.equals(cachedUrl) && System.currentTimeMillis() - checkedAt < REFRESH_MILLIS && !cache.isEmpty()) {
            main.post(() -> callback.onLoaded(snapshot()));
            return;
        }
        loading = true;
        worker.execute(() -> {
            Map<String, XmltvParser.Schedule> schedules = new HashMap<>();
            try {
                Set<String> ids = new HashSet<>();
                for (Channel channel : playlist.channels) if (!channel.tvgId.trim().isEmpty()) ids.add(channel.tvgId);
                if (!ids.isEmpty()) for (String candidate : playlist.epgUrl.split(",")) {
                    String address = candidate.trim();
                    if (!(address.startsWith("https://") || address.startsWith("http://"))) continue;
                    try {
                        java.net.HttpURLConnection connection = (java.net.HttpURLConnection) new java.net.URL(address).openConnection();
                        connection.setConnectTimeout(8000);
                        connection.setReadTimeout(12000);
                        connection.setInstanceFollowRedirects(true);
                        connection.setRequestProperty("User-Agent", "TVNhaPlus/0.1 AndroidTV");
                        try {
                            int status = connection.getResponseCode();
                            if (status < 200 || status >= 300) continue;
                            if (connection.getContentLengthLong() > MAX_XML_BYTES) continue;
                            try (InputStream raw = new BufferedInputStream(connection.getInputStream());
                                 InputStream source = address.toLowerCase(java.util.Locale.ROOT).contains(".gz")
                                         ? new GZIPInputStream(raw) : raw) {
                                schedules = XmltvParser.currentAndNext(new BoundedInputStream(source, MAX_XML_BYTES), ids, System.currentTimeMillis());
                            }
                        } finally { connection.disconnect(); }
                        if (hasAnySchedule(schedules)) break;
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {
                schedules = snapshot();
            }
            synchronized (this) {
                if (!schedules.isEmpty()) cache.clear();
                cache.putAll(schedules);
                cachedUrl = playlist.epgUrl;
                checkedAt = System.currentTimeMillis();
                loading = false;
                writeCache();
            }
            Map<String, XmltvParser.Schedule> finalSchedules = snapshot();
            main.post(() -> callback.onLoaded(finalSchedules));
        });
    }

    private synchronized Map<String, XmltvParser.Schedule> snapshot() { return new HashMap<>(cache); }

    private static boolean hasAnySchedule(Map<String, XmltvParser.Schedule> values) {
        for (XmltvParser.Schedule schedule : values.values())
            if (schedule.current != null || schedule.next != null) return true;
        return false;
    }

    private synchronized void readCache() {
        if (!cacheFile.isFile()) return;
        try (FileInputStream input = new FileInputStream(cacheFile); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
            JSONObject json = new JSONObject(output.toString(StandardCharsets.UTF_8.name()));
            cachedUrl = json.optString("url", "");
            checkedAt = json.optLong("checkedAt", 0);
            JSONArray entries = json.optJSONArray("entries");
            if (entries != null) for (int i = 0; i < entries.length(); i++) {
                JSONObject item = entries.getJSONObject(i);
                String id = item.optString("id");
                Programme current = programme(id, item.optJSONObject("current"));
                Programme next = programme(id, item.optJSONObject("next"));
                cache.put(id, new XmltvParser.Schedule(current, next));
            }
        } catch (Exception ignored) { cache.clear(); }
    }

    private synchronized void writeCache() {
        try {
            JSONObject json = new JSONObject();
            json.put("url", cachedUrl);
            json.put("checkedAt", checkedAt);
            JSONArray entries = new JSONArray();
            for (Map.Entry<String, XmltvParser.Schedule> entry : cache.entrySet()) {
                JSONObject item = new JSONObject();
                item.put("id", entry.getKey());
                item.put("current", toJson(entry.getValue().current));
                item.put("next", toJson(entry.getValue().next));
                entries.put(item);
            }
            json.put("entries", entries);
            File temporary = new File(appContext.getFilesDir(), "epg-cache-v1.json.tmp");
            try (FileOutputStream output = new FileOutputStream(temporary)) {
                output.write(json.toString().getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            try { Files.move(temporary.toPath(), cacheFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (Exception ignored) { Files.move(temporary.toPath(), cacheFile.toPath(), StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) {}
    }

    private static JSONObject toJson(Programme programme) {
        if (programme == null) return null;
        JSONObject value = new JSONObject();
        try {
            value.put("title", programme.title);
            value.put("start", programme.startMillis);
            value.put("stop", programme.stopMillis);
        } catch (Exception ignored) {}
        return value;
    }
    private static Programme programme(String id, JSONObject value) {
        return value == null ? null : new Programme(id, value.optString("title"), value.optLong("start"), value.optLong("stop"));
    }

    private static final class BoundedInputStream extends java.io.FilterInputStream {
        private final long limit;
        private long count;
        BoundedInputStream(InputStream input, long limit) { super(input); this.limit = limit; }
        @Override public int read() throws java.io.IOException {
            int value = super.read();
            if (value >= 0 && ++count > limit) throw new java.io.IOException("Tệp XMLTV vượt quá giới hạn 64 MB.");
            return value;
        }
        @Override public int read(byte[] buffer, int offset, int length) throws java.io.IOException {
            int value = super.read(buffer, offset, (int) Math.min(length, limit - count + 1));
            if (value > 0) { count += value; if (count > limit) throw new java.io.IOException("Tệp XMLTV vượt quá giới hạn 64 MB."); }
            return value;
        }
    }
}
