package vn.hoanghoa.tvnhaplus.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class M3uParser {
    private static final Pattern ATTRIBUTE = Pattern.compile("([\\w-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s,]+))");

    private M3uParser() {}

    public static Playlist parse(Reader source, String sourceUrl) throws IOException {
        BufferedReader reader = source instanceof BufferedReader ? (BufferedReader) source : new BufferedReader(source);
        String playlistName = "Playlist IPTV";
        String epgUrl = "";
        String pendingName = null;
        Map<String, String> pendingAttributes = null;
        List<Channel> channels = new ArrayList<>();
        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.regionMatches(true, 0, "#EXTM3U", 0, 7)) {
                Map<String, String> attrs = attributes(line);
                epgUrl = first(attrs, "url-tvg", "x-tvg-url", "tvg-url");
                playlistName = first(attrs, "name", "title");
                continue;
            }
            if (line.regionMatches(true, 0, "#EXTINF:", 0, 8)) {
                int comma = displayNameIndex(line);
                String metadata = comma >= 0 ? line.substring(0, comma) : line;
                String displayName = comma >= 0 ? line.substring(comma + 1).trim() : "";
                pendingAttributes = attributes(metadata);
                if (displayName.isEmpty()) displayName = pendingAttributes.getOrDefault("tvg-name", "").trim();
                pendingName = displayName;
                continue;
            }
            if (line.startsWith("#")) continue;
            if (pendingName == null || pendingAttributes == null) continue;
            String streamUrl = resolve(sourceUrl, line);
            if (streamUrl.isEmpty()) {
                pendingName = null;
                pendingAttributes = null;
                continue;
            }
            String tvgId = pendingAttributes.getOrDefault("tvg-id", "").trim();
            String id = stableId(tvgId, streamUrl, channels.size());
            String group = pendingAttributes.getOrDefault("group-title", "").trim();
            String logo = pendingAttributes.getOrDefault("tvg-logo", "").trim();
            channels.add(new Channel(id, pendingName.trim().isEmpty() ? "Kênh " + (channels.size() + 1) : pendingName,
                    streamUrl, logo, group, tvgId, channels.size() + 1));
            pendingName = null;
            pendingAttributes = null;
        }
        if (channels.isEmpty()) throw new IOException("Playlist không có kênh M3U hợp lệ.");
        return new Playlist(playlistName, sourceUrl, epgUrl, channels);
    }

    private static int displayNameIndex(String line) {
        boolean quoted = false;
        char quote = 0;
        for (int i = 8; i < line.length(); i++) {
            char c = line.charAt(i);
            if ((c == '"' || c == '\'') && (!quoted || c == quote)) {
                if (quoted) quoted = false;
                else { quoted = true; quote = c; }
            } else if (c == ',' && !quoted) return i;
        }
        return -1;
    }

    private static Map<String, String> attributes(String text) {
        Map<String, String> result = new LinkedHashMap<>();
        Matcher matcher = ATTRIBUTE.matcher(text);
        while (matcher.find()) {
            String value = matcher.group(2) != null ? matcher.group(2)
                    : matcher.group(3) != null ? matcher.group(3) : matcher.group(4);
            result.put(matcher.group(1).toLowerCase(Locale.ROOT), value == null ? "" : value);
        }
        return result;
    }

    private static String first(Map<String, String> values, String... keys) {
        for (String key : keys) {
            String value = values.get(key);
            if (value != null && !value.trim().isEmpty()) return value.trim();
        }
        return "";
    }

    private static String resolve(String sourceUrl, String candidate) {
        try {
            URI uri = new URI(candidate);
            if (!uri.isAbsolute()) uri = new URI(sourceUrl).resolve(uri);
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) return "";
            return uri.toString();
        } catch (URISyntaxException | IllegalArgumentException ignored) {
            return "";
        }
    }

    private static String stableId(String tvgId, String streamUrl, int ordinal) {
        String seed = tvgId.trim().isEmpty() ? streamUrl + "#" + ordinal : tvgId + "#" + streamUrl;
        return Integer.toHexString(seed.hashCode()) + "-" + ordinal;
    }
}
