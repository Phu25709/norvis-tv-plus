package vn.hoanghoa.tvnhaplus.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Playlist {
    public final String name;
    public final String sourceUrl;
    public final String epgUrl;
    public final List<Channel> channels;

    public Playlist(String name, String sourceUrl, String epgUrl, List<Channel> channels) {
        this.name = name == null || name.trim().isEmpty() ? "Playlist IPTV" : name;
        this.sourceUrl = sourceUrl == null ? "" : sourceUrl;
        this.epgUrl = epgUrl == null ? "" : epgUrl;
        this.channels = Collections.unmodifiableList(ChannelNumbering.orderedAndNumbered(channels));
    }
}
