package vn.hoanghoa.tvnhaplus.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PlaylistRepository {
    public interface LoadCallback { void onLoaded(Playlist playlist); }
    public interface ImportCallback {
        void onComplete(Playlist playlist, Exception error);
    }

    private static final long MAX_PLAYLIST_BYTES = 32L * 1024L * 1024L;
    private static final String LAST_PLAYLIST_REFRESH = "last_playlist_refresh";
    private final Context appContext;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final File storeFile;
    private final SharedPreferences preferences;
    private Playlist playlist;
    private final Set<String> favorites = new HashSet<>();
    private String lastChannelId = "";
    private final ArrayList<LoadCallback> loadCallbacks = new ArrayList<>();
    private boolean loading;
    private boolean loaded;
    private boolean writeScheduled;
    private long stateVersion;

    public PlaylistRepository(Context context) {
        appContext = context.getApplicationContext();
        storeFile = new File(appContext.getFilesDir(), "playlist-v1.json");
        preferences = appContext.getSharedPreferences("tv_nha_plus", Context.MODE_PRIVATE);
    }

    public synchronized Playlist playlist() { return playlist; }
    public synchronized boolean isLoaded() { return loaded; }
    public synchronized String lastChannelId() { return lastChannelId; }
    public long lastSuccessfulPlaylistRefreshMillis() {
        return preferences.getLong(LAST_PLAYLIST_REFRESH, 0L);
    }
    public synchronized Set<String> favorites() { return Collections.unmodifiableSet(new HashSet<>(favorites)); }

    public void loadAsync(LoadCallback callback) {
        synchronized (this) {
            if (loaded) {
                Playlist saved = playlist;
                main.post(() -> callback.onLoaded(saved));
                return;
            }
            loadCallbacks.add(callback);
            if (loading) return;
            loading = true;
        }
        worker.execute(() -> {
            readStore();
            ArrayList<LoadCallback> callbacks;
            Playlist saved;
            synchronized (this) {
                loaded = true;
                loading = false;
                callbacks = new ArrayList<>(loadCallbacks);
                loadCallbacks.clear();
                saved = playlist;
            }
            main.post(() -> { for (LoadCallback item : callbacks) item.onLoaded(saved); });
        });
    }

    public synchronized boolean isFavorite(String channelId) { return favorites.contains(channelId); }

    public synchronized void toggleFavorite(String channelId) {
        if (!favorites.add(channelId)) favorites.remove(channelId);
        preferences.edit().putStringSet("favorites", new HashSet<>(favorites)).apply();
        writeStore();
    }

    public synchronized void setLastChannel(String channelId) {
        lastChannelId = channelId == null ? "" : channelId;
        preferences.edit().putString("last_channel", lastChannelId).apply();
        writeStore();
    }

    public void importFromUrl(String address, ImportCallback callback) {
        worker.execute(() -> {
            Playlist imported = null;
            Exception failure = null;
            try {
                String url = address == null ? "" : address.trim();
                if (!(url.startsWith("https://") || url.startsWith("http://")))
                    throw new IllegalArgumentException("Đường dẫn phải bắt đầu bằng http:// hoặc https://");
                java.net.HttpURLConnection connection = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "TVNhaPlus/0.1 AndroidTV");
                try {
                    int status = connection.getResponseCode();
                    if (status < 200 || status >= 300) throw new java.io.IOException("Máy chủ trả về HTTP " + status);
                    long declaredSize = connection.getContentLengthLong();
                    if (declaredSize > MAX_PLAYLIST_BYTES) throw new java.io.IOException("Playlist lớn hơn giới hạn 32 MB.");
                    byte[] bytes;
                    try (BufferedInputStream input = new BufferedInputStream(connection.getInputStream());
                         ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                        byte[] buffer = new byte[16384];
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            if (output.size() + read > MAX_PLAYLIST_BYTES) throw new java.io.IOException("Playlist lớn hơn giới hạn 32 MB.");
                            output.write(buffer, 0, read);
                        }
                        bytes = output.toByteArray();
                    }
                    String body = new String(bytes, StandardCharsets.UTF_8);
                    if (body.startsWith("\uFEFF")) body = body.substring(1);
                    try (Reader reader = new InputStreamReader(new java.io.ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8)) {
                        imported = M3uParser.parse(reader, url);
                    }
                } finally {
                    connection.disconnect();
                }
                synchronized (this) {
                    Channel previousLast = findById(playlist, lastChannelId);
                    ArrayList<Channel> previousFavorites = new ArrayList<>();
                    for (Channel channel : playlist == null ? Collections.<Channel>emptyList() : playlist.channels)
                        if (favorites.contains(channel.id)) previousFavorites.add(channel);
                    String updatedLast = "";
                    Channel mappedLast = findMatchingChannel(imported, previousLast);
                    if (mappedLast != null) updatedLast = mappedLast.id;
                    playlist = imported;
                    lastChannelId = updatedLast;
                    favorites.clear();
                    for (Channel oldFavorite : previousFavorites) {
                        Channel mappedFavorite = findMatchingChannel(imported, oldFavorite);
                        if (mappedFavorite != null) favorites.add(mappedFavorite.id);
                    }
                    preferences.edit().putString("last_channel", lastChannelId)
                            .putStringSet("favorites", new HashSet<>(favorites))
                            .putLong(LAST_PLAYLIST_REFRESH, System.currentTimeMillis()).apply();
                    writeStore();
                }
            } catch (Exception ex) {
                failure = ex;
            }
            Playlist result = imported;
            Exception error = failure;
            main.post(() -> callback.onComplete(result, error));
        });
    }

    public static Channel findMatchingChannel(Playlist source, Channel reference) {
        if (source == null || reference == null) return null;
        Channel best = null;
        int bestScore = 0;
        for (Channel candidate : source.channels) {
            if (candidate.id.equals(reference.id)) return candidate;
            boolean sameTvgId = !reference.tvgId.isEmpty() && reference.tvgId.equalsIgnoreCase(candidate.tvgId);
            boolean sameName = normalize(reference.name).equals(normalize(candidate.name));
            boolean sameGroup = normalize(reference.groupTitle).equals(normalize(candidate.groupTitle));
            int score = (sameTvgId ? 8 : 0) + (sameName ? 4 : 0) + (sameGroup ? 2 : 0);
            if (score > bestScore) {
                best = candidate;
                bestScore = score;
            }
        }
        return bestScore >= 4 ? best : null;
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ").toLowerCase(java.util.Locale.ROOT);
    }

    private static Channel findById(Playlist source, String id) {
        if (source == null || id == null || id.isEmpty()) return null;
        for (Channel channel : source.channels) if (channel.id.equals(id)) return channel;
        return null;
    }

    private synchronized void readStore() {
        if (!storeFile.isFile()) return;
        try (FileInputStream input = new FileInputStream(storeFile)) {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            JSONObject json = new JSONObject(output.toString(StandardCharsets.UTF_8.name()));
            JSONArray values = json.optJSONArray("channels");
            ArrayList<Channel> channels = new ArrayList<>();
            if (values != null) for (int i = 0; i < values.length(); i++) channels.add(Channel.fromJson(values.getJSONObject(i)));
            if (!channels.isEmpty()) playlist = new Playlist(json.optString("name"), json.optString("sourceUrl"), json.optString("epgUrl"), channels);
            lastChannelId = preferences.getString("last_channel", json.optString("lastChannelId", ""));
            JSONArray savedFavorites = json.optJSONArray("favorites");
            if (savedFavorites != null) for (int i = 0; i < savedFavorites.length(); i++) favorites.add(savedFavorites.getString(i));
            Set<String> preferenceFavorites = preferences.getStringSet("favorites", null);
            if (preferenceFavorites != null) {
                favorites.clear();
                favorites.addAll(new HashSet<>(preferenceFavorites));
            }
        } catch (Exception ignored) {
            playlist = null;
            favorites.clear();
            lastChannelId = "";
        }
    }

    private void writeStore() {
        synchronized (this) {
            stateVersion++;
            if (writeScheduled) return;
            writeScheduled = true;
        }
        worker.execute(this::drainWrites);
    }

    private void drainWrites() {
        while (true) {
            StoreSnapshot snapshot;
            synchronized (this) {
                snapshot = new StoreSnapshot(playlist, lastChannelId, new HashSet<>(favorites), stateVersion);
            }
            writeSnapshot(snapshot);
            synchronized (this) {
                if (stateVersion == snapshot.version) {
                    writeScheduled = false;
                    return;
                }
            }
        }
    }

    private void writeSnapshot(StoreSnapshot snapshot) {
        try {
            JSONObject json = new JSONObject();
            json.put("version", 1);
            json.put("name", snapshot.playlist == null ? "" : snapshot.playlist.name);
            json.put("sourceUrl", snapshot.playlist == null ? "" : snapshot.playlist.sourceUrl);
            json.put("epgUrl", snapshot.playlist == null ? "" : snapshot.playlist.epgUrl);
            json.put("lastChannelId", snapshot.lastChannelId);
            JSONArray channels = new JSONArray();
            if (snapshot.playlist != null) for (Channel channel : snapshot.playlist.channels) channels.put(channel.toJson());
            json.put("channels", channels);
            JSONArray savedFavorites = new JSONArray();
            for (String id : snapshot.favorites) savedFavorites.put(id);
            json.put("favorites", savedFavorites);
            File temporary = new File(appContext.getFilesDir(), "playlist-v1.json.tmp");
            try (FileOutputStream output = new FileOutputStream(temporary)) {
                output.write(json.toString().getBytes(StandardCharsets.UTF_8));
                output.getFD().sync();
            }
            try {
                Files.move(temporary.toPath(), storeFile.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception moveError) {
                Files.move(temporary.toPath(), storeFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ignored) {}
    }

    private static final class StoreSnapshot {
        final Playlist playlist;
        final String lastChannelId;
        final Set<String> favorites;
        final long version;
        StoreSnapshot(Playlist playlist, String lastChannelId, Set<String> favorites, long version) {
            this.playlist = playlist;
            this.lastChannelId = lastChannelId;
            this.favorites = favorites;
            this.version = version;
        }
    }
}
