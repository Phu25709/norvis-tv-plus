package vn.hoanghoa.tvnhaplus.data;

public final class Programme {
    public final String channelId;
    public final String title;
    public final long startMillis;
    public final long stopMillis;

    public Programme(String channelId, String title, long startMillis, long stopMillis) {
        this.channelId = channelId;
        this.title = title == null ? "" : title;
        this.startMillis = startMillis;
        this.stopMillis = stopMillis;
    }
}
