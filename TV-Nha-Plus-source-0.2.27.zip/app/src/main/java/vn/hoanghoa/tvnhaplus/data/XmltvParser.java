package vn.hoanghoa.tvnhaplus.data;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public final class XmltvParser {
    public static final class Schedule {
        public final Programme current;
        public final Programme next;
        public Schedule(Programme current, Programme next) { this.current = current; this.next = next; }
    }

    private XmltvParser() {}

    public static Map<String, Schedule> currentAndNext(InputStream input, Set<String> channelIds, long now) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false);
        parser.setInput(input, "UTF-8");
        HashSet<String> requested = new HashSet<>(channelIds);
        Map<String, Programme> current = new HashMap<>();
        Map<String, Programme> next = new HashMap<>();
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && "programme".equals(parser.getName())) {
                String channel = parser.getAttributeValue(null, "channel");
                String startText = parser.getAttributeValue(null, "start");
                String stopText = parser.getAttributeValue(null, "stop");
                if (channel != null && requested.contains(channel)) {
                    long start = parseDate(startText);
                    long stop = parseDate(stopText);
                    String title = "";
                    int depth = parser.getDepth();
                    while (true) {
                        int child = parser.next();
                        if (child == XmlPullParser.END_TAG && parser.getDepth() == depth) break;
                        if (child == XmlPullParser.END_DOCUMENT) break;
                        if (child == XmlPullParser.START_TAG && ("title".equals(parser.getName()) || (title.isEmpty() && "sub-title".equals(parser.getName()))))
                            title = parser.nextText().trim();
                    }
                    if (!title.isEmpty() && start > 0 && stop > start) {
                        Programme programme = new Programme(channel, title, start, stop);
                        if (start <= now && stop > now) current.put(channel, programme);
                        else if (start > now) {
                            Programme old = next.get(channel);
                            if (old == null || start < old.startMillis) next.put(channel, programme);
                        }
                    }
                }
            }
            event = parser.next();
        }
        HashMap<String, Schedule> result = new HashMap<>();
        for (String id : requested) result.put(id, new Schedule(current.get(id), next.get(id)));
        return result;
    }

    private static long parseDate(String value) {
        if (value == null || value.trim().isEmpty()) return 0;
        String text = value.trim().replaceAll("\\s+", " ");
        String[] patterns = {"yyyyMMddHHmmss Z", "yyyyMMddHHmm Z", "yyyyMMddHHmmss", "yyyyMMddHHmm"};
        for (String pattern : patterns) {
            SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
            format.setLenient(false);
            if (!pattern.contains("Z")) format.setTimeZone(TimeZone.getTimeZone("UTC"));
            ParsePosition position = new ParsePosition(0);
            Date date = format.parse(text, position);
            if (date != null && position.getIndex() == text.length()) return date.getTime();
        }
        return 0;
    }
}
