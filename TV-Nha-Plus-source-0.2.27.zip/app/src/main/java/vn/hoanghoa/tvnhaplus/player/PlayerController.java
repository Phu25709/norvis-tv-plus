package vn.hoanghoa.tvnhaplus.player;

import android.content.Context;
import android.os.Build;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;

import androidx.media3.common.MediaItem;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import vn.hoanghoa.tvnhaplus.data.Channel;

import java.util.ArrayList;
import java.util.List;

public final class PlayerController {
    public static final class AudioTrackOption {
        public final String label;
        public final boolean selected;
        private final TrackGroup group;
        private final int trackIndex;
        AudioTrackOption(String label, boolean selected, TrackGroup group, int trackIndex) {
            this.label = label;
            this.selected = selected;
            this.group = group;
            this.trackIndex = trackIndex;
        }
    }

    public static final class SubtitleTrackOption {
        public final String label;
        public final boolean selected;
        private final TrackGroup group;
        private final int trackIndex;
        SubtitleTrackOption(String label, boolean selected, TrackGroup group, int trackIndex) {
            this.label = label;
            this.selected = selected;
            this.group = group;
            this.trackIndex = trackIndex;
        }
    }

    public interface Listener {
        void onChannelChanged(Channel channel);
        void onPlaybackError(String message);
        void onRenderedFirstFrame();
        void onPlaybackState(int state);
        void onTechnicalInfo(String summary);
    }

    private final ExoPlayer player;
    private final PlayerView playerView;
    private final Listener listener;
    private Channel current;
    private int videoWidth = Format.NO_VALUE;
    private int videoHeight = Format.NO_VALUE;
    private float videoFrameRate = Format.NO_VALUE;
    private int videoBitrate = Format.NO_VALUE;
    private String videoCodec = "";
    private Format selectedAudioFormat;

    public PlayerController(Context context, PlayerView view, Listener listener) {
        this.listener = listener;
        this.playerView = view;
        player = new ExoPlayer.Builder(context.getApplicationContext()).build();
        view.setPlayer(player);
        view.setUseController(false);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) { listener.onPlaybackState(state); }
            @Override public void onRenderedFirstFrame() {
                updateDisplayFrameRate();
                listener.onRenderedFirstFrame();
            }
            @Override public void onTracksChanged(Tracks tracks) {
                videoWidth = Format.NO_VALUE;
                videoHeight = Format.NO_VALUE;
                videoFrameRate = Format.NO_VALUE;
                videoBitrate = Format.NO_VALUE;
                videoCodec = "";
                selectedAudioFormat = null;
                for (Tracks.Group group : tracks.getGroups()) {
                    if (group.getType() == C.TRACK_TYPE_VIDEO) {
                        for (int i = 0; i < group.length; i++) if (group.isTrackSelected(i)) {
                            Format format = group.getTrackFormat(i);
                            videoWidth = format.width;
                            videoHeight = format.height;
                            videoFrameRate = format.frameRate;
                            videoBitrate = format.bitrate;
                            videoCodec = videoCodecName(format.sampleMimeType);
                            break;
                        }
                    } else if (group.getType() == C.TRACK_TYPE_AUDIO) {
                        for (int i = 0; i < group.length; i++) if (group.isTrackSelected(i)) {
                            selectedAudioFormat = group.getTrackFormat(i);
                            break;
                        }
                    }
                }
                updateDisplayFrameRate();
                publishTechnicalInfo();
            }
            @Override public void onVideoSizeChanged(androidx.media3.common.VideoSize size) {
                if (size.width > 0 && size.height > 0) {
                    videoWidth = size.width;
                    videoHeight = size.height;
                    updateDisplayFrameRate();
                    publishTechnicalInfo();
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                String message;
                switch (error.errorCode) {
                    case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED:
                    case PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT:
                        message = "Không kết nối được tới nguồn kênh. Hãy kiểm tra mạng rồi thử lại.";
                        break;
                    case PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED:
                    case PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED:
                        message = "Nguồn đang dùng định dạng chưa được hỗ trợ.";
                        break;
                    case PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED:
                        message = "Danh sách phát của nguồn kênh không hợp lệ.";
                        break;
                    default:
                        message = "Mã lỗi " + PlaybackException.getErrorCodeName(error.errorCode);
                }
                listener.onPlaybackError(message);
            }
        });
    }

    public void play(Channel channel) {
        player.stop();
        player.clearMediaItems();
        videoWidth = Format.NO_VALUE;
        videoHeight = Format.NO_VALUE;
        videoFrameRate = Format.NO_VALUE;
        videoBitrate = Format.NO_VALUE;
        videoCodec = "";
        selectedAudioFormat = null;
        current = channel;
        listener.onChannelChanged(channel);
        publishTechnicalInfo();
        MediaItem.Builder itemBuilder = new MediaItem.Builder().setUri(channel.streamUrl).setMediaId(channel.id);
        String lowerUrl = channel.streamUrl.toLowerCase(java.util.Locale.ROOT);
        if (lowerUrl.contains(".m3u8") || lowerUrl.contains("tv360") || lowerUrl.contains("format=m3u"))
            itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8);
        MediaItem item = itemBuilder.build();
        player.setMediaItem(item);
        player.prepare();
        player.play();
    }

    public void pause() { player.pause(); }
    public void resume() { player.play(); }
    public Channel currentChannel() { return current; }
    public void updateCurrentChannelMetadata(Channel channel) {
        boolean displayChanged = current == null || current.channelNumber != channel.channelNumber
                || !current.name.equals(channel.name);
        current = channel;
        if (displayChanged) listener.onChannelChanged(channel);
    }
    public List<AudioTrackOption> audioTracks() {
        ArrayList<AudioTrackOption> result = new ArrayList<>();
        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() != C.TRACK_TYPE_AUDIO) continue;
            for (int i = 0; i < group.length; i++) {
                if (!group.isTrackSupported(i)) continue;
                Format format = group.getTrackFormat(i);
                String label = audioLabel(format);
                result.add(new AudioTrackOption(label, group.isTrackSelected(i), group.getMediaTrackGroup(), i));
            }
        }
        return result;
    }
    public void selectAudioTrack(AudioTrackOption option) {
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setOverrideForType(new TrackSelectionOverride(option.group, option.trackIndex)).build());
    }
    public void useAutomaticAudioTrackSelection() {
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO).build());
    }
    public List<SubtitleTrackOption> subtitleTracks() {
        ArrayList<SubtitleTrackOption> result = new ArrayList<>();
        for (Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() != C.TRACK_TYPE_TEXT) continue;
            for (int i = 0; i < group.length; i++) {
                if (!group.isTrackSupported(i)) continue;
                Format format = group.getTrackFormat(i);
                result.add(new SubtitleTrackOption(subtitleLabel(format), group.isTrackSelected(i), group.getMediaTrackGroup(), i));
            }
        }
        return result;
    }
    public void selectSubtitleTrack(SubtitleTrackOption option) {
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(new TrackSelectionOverride(option.group, option.trackIndex)).build());
    }
    public void disableSubtitles() {
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .clearOverridesOfType(C.TRACK_TYPE_TEXT).build());
    }
    public void useAutomaticSubtitleSelection() {
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .clearOverridesOfType(C.TRACK_TYPE_TEXT).build());
    }
    public boolean seekBy(long offsetMillis) {
        if (!player.isCurrentMediaItemSeekable()) return false;
        long target = Math.max(0, player.getCurrentPosition() + offsetMillis);
        long duration = player.getDuration();
        if (duration != C.TIME_UNSET) target = Math.min(target, duration);
        player.seekTo(target);
        return true;
    }
    public void release() { player.release(); }

    private static String audioLabel(Format format) {
        String codec = audioCodec(format);
        String channels = channelLayout(format.channelCount);
        String language = format.language == null || format.language.isEmpty() ? "" : format.language.toUpperCase(java.util.Locale.ROOT) + " · ";
        return language + codec + " · " + channels;
    }

    private void publishTechnicalInfo() {
        String video = videoResolution(videoWidth, videoHeight);
        if (!videoCodec.isEmpty()) video += " · " + videoCodec;
        if (videoFrameRate > 0) video += String.format(java.util.Locale.ROOT, " · %.0f fps", videoFrameRate);
        if (videoBitrate > 0) video += String.format(java.util.Locale.ROOT, " · %.1f Mbps", videoBitrate / 1_000_000f);
        String audio = selectedAudioFormat == null ? "Audio chưa rõ"
                : audioCodec(selectedAudioFormat) + " " + channelLayout(selectedAudioFormat.channelCount);
        listener.onTechnicalInfo(video + "  ·  " + audio);
    }

    /**
     * Ask Android TV to match a true 50 fps source when the device supports it.
     * This avoids 50-to-60 Hz cadence judder without changing ordinary 25/30 fps channels.
     */
    private void updateDisplayFrameRate() {
        if (Build.VERSION.SDK_INT < 30) return;
        View surfaceView = playerView.getVideoSurfaceView();
        if (!(surfaceView instanceof SurfaceView)) return;
        Surface surface = ((SurfaceView) surfaceView).getHolder().getSurface();
        if (surface == null || !surface.isValid()) return;
        float sourceRate = videoFrameRate;
        if (sourceRate >= 47f && sourceRate <= 53f) {
            surface.setFrameRate(sourceRate, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                    Surface.CHANGE_FRAME_RATE_ALWAYS);
        } else {
            surface.setFrameRate(0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT,
                    Surface.CHANGE_FRAME_RATE_ONLY_IF_SEAMLESS);
        }
    }

    private static String videoResolution(int width, int height) {
        if (width <= 0 || height <= 0) return "Video đang đọc tín hiệu";
        String tier = height >= 2160 || width >= 3840 ? "4K"
                : height >= 1080 || width >= 1920 ? "Full HD"
                : height >= 720 || width >= 1280 ? "HD" : "SD";
        return tier + " " + height + "p";
    }

    private static String audioCodec(Format format) {
        String mime = format.sampleMimeType == null ? "" : format.sampleMimeType.toLowerCase(java.util.Locale.ROOT);
        if (mime.contains("eac3-joc")) return "Dolby Atmos";
        if (mime.contains("eac3")) return "Dolby Digital Plus";
        if (mime.contains("ac3")) return "Dolby Digital";
        if (mime.contains("truehd")) return "Dolby TrueHD";
        if (mime.contains("dts")) return "DTS";
        if (mime.contains("aac") || mime.contains("mp4a-latm")) return "AAC";
        if (mime.contains("mpeg")) return "MPEG Audio";
        return mime.isEmpty() ? "Audio" : mime;
    }

    private static String channelLayout(int count) {
        if (count == 6) return "5.1";
        if (count == 8) return "7.1";
        if (count == 2) return "Stereo";
        return count > 0 ? count + " kênh" : "số kênh chưa rõ";
    }

    private static String videoCodecName(String mime) {
        if (mime == null) return "";
        String value = mime.toLowerCase(java.util.Locale.ROOT);
        if (value.contains("hevc") || value.contains("h265")) return "HEVC";
        if (value.contains("avc") || value.contains("h264")) return "H.264";
        if (value.contains("av01") || value.contains("av1")) return "AV1";
        if (value.contains("vp9")) return "VP9";
        return "";
    }

    private static String subtitleLabel(Format format) {
        String language = format.language == null || format.language.isEmpty()
                ? "" : new java.util.Locale(format.language).getDisplayLanguage(new java.util.Locale("vi", "VN")) + " · ";
        String mime = format.sampleMimeType == null ? "" : format.sampleMimeType.toLowerCase(java.util.Locale.ROOT);
        String type = mime.contains("vtt") ? "WebVTT"
                : mime.contains("subrip") ? "SRT"
                : mime.contains("ttml") ? "TTML"
                : mime.contains("cea-608") ? "CEA-608"
                : mime.contains("cea-708") ? "CEA-708"
                : mime.isEmpty() ? "Phụ đề" : mime;
        String label = format.label == null || format.label.trim().isEmpty() ? type : format.label.trim() + " · " + type;
        return language + label;
    }
}
