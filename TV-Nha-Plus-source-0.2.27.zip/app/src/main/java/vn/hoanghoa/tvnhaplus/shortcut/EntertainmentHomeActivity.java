package vn.hoanghoa.tvnhaplus.shortcut;

public final class EntertainmentHomeActivity extends ShortcutEntryActivity {
    @Override String targetName() { return "Giải Trí"; }
    @Override boolean opensGroup() { return true; }
}
