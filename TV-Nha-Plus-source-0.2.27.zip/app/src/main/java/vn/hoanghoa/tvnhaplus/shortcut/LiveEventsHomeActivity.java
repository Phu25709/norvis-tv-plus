package vn.hoanghoa.tvnhaplus.shortcut;

public final class LiveEventsHomeActivity extends ShortcutEntryActivity {
    @Override String targetName() { return "LIVE EVENTS"; }
    @Override boolean opensGroup() { return true; }
}
