package vn.hoanghoa.tvnhaplus.shortcut;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import vn.hoanghoa.tvnhaplus.MainActivity;
import vn.hoanghoa.tvnhaplus.PlayerActivity;
import vn.hoanghoa.tvnhaplus.TvNhaPlusApp;
import vn.hoanghoa.tvnhaplus.data.Channel;
import vn.hoanghoa.tvnhaplus.data.Playlist;
import vn.hoanghoa.tvnhaplus.data.PlaylistRepository;

abstract class ShortcutEntryActivity extends Activity {
    abstract String targetName();
    abstract boolean opensGroup();

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        PlaylistRepository repository = ((TvNhaPlusApp) getApplication()).playlistRepository();
        repository.loadAsync(playlist -> openTarget(playlist));
    }

    private void openTarget(Playlist playlist) {
        if (isFinishing()) return;
        if (playlist == null || playlist.channels.isEmpty()) {
            showUnavailable("Chưa có playlist", "Mở TV Nhà Plus để thêm playlist M3U trước.", true);
            return;
        }

        String query = targetName().trim();
        Channel match = opensGroup() ? findGroupChannel(playlist, query) : findChannel(playlist, query);
        if (match == null) {
            String detail = opensGroup()
                    ? "Playlist hiện tại chưa có nhóm “" + query + "”. Hãy kiểm tra playlist đang dùng."
                    : "Không tìm thấy kênh “" + query + "” trong playlist hiện tại.";
            showUnavailable("Chưa tìm thấy nội dung", detail, false);
            return;
        }

        Intent intent = new Intent(this, PlayerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (opensGroup()) {
            intent.putExtra(PlayerActivity.EXTRA_GUIDE_GROUP, match.groupTitle);
        } else {
            intent.putExtra(PlayerActivity.EXTRA_CHANNEL_ID, match.id);
        }
        startActivity(intent);
        finish();
    }

    private static Channel findChannel(Playlist playlist, String query) {
        for (Channel channel : playlist.channels) if (channel.name.trim().equalsIgnoreCase(query)) return channel;
        for (Channel channel : playlist.channels) if (channel.tvgId.trim().equalsIgnoreCase(query)) return channel;
        for (Channel channel : playlist.channels) if (channel.name.trim().toLowerCase(java.util.Locale.ROOT)
                .startsWith(query.toLowerCase(java.util.Locale.ROOT) + " ")) return channel;
        return null;
    }

    private static Channel findGroupChannel(Playlist playlist, String query) {
        String needle = query.toLowerCase(java.util.Locale.ROOT);
        for (Channel channel : playlist.channels)
            if (channel.groupTitle.trim().equalsIgnoreCase(query)) return channel;
        for (Channel channel : playlist.channels)
            if (channel.groupTitle.toLowerCase(java.util.Locale.ROOT).contains(needle)) return channel;
        return null;
    }

    private void showUnavailable(String title, String detail, boolean offerSetup) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(detail)
                .setNegativeButton("Đóng", (d, w) -> finish());
        if (offerSetup) dialog.setPositiveButton("Mở TV Nhà Plus", (d, w) -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
        dialog.setOnCancelListener(d -> finish()).show();
    }
}
