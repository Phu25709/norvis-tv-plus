package vn.hoanghoa.tvnhaplus.shortcut;

public final class Vtv1HomeActivity extends ShortcutEntryActivity {
    @Override String targetName() { return "VTV1"; }
    @Override boolean opensGroup() { return false; }
}
