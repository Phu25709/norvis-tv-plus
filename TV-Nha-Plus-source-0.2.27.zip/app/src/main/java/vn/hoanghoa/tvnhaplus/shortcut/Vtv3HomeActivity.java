package vn.hoanghoa.tvnhaplus.shortcut;

public final class Vtv3HomeActivity extends ShortcutEntryActivity {
    @Override String targetName() { return "VTV3"; }
    @Override boolean opensGroup() { return false; }
}
