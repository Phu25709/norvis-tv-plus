package vn.hoanghoa.tvnhaplus.shortcut;

public final class Vtv6HomeActivity extends ShortcutEntryActivity {
    @Override String targetName() { return "VTV6"; }
    @Override boolean opensGroup() { return false; }
}
