package vn.hoanghoa.tvnhaplus.ui;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import vn.hoanghoa.tvnhaplus.data.Channel;

final class ChannelAdapter extends BaseAdapter {
    interface Listener { void onChannelClicked(Channel channel); }
    private final Context context;
    private final Listener listener;
    private final ExecutorService logoWorker = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> logos = new LruCache<String, Bitmap>(8 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return Math.max(1, value.getByteCount() / 1024); }
    };
    private final List<Channel> channels = new ArrayList<>();
    private final java.util.Set<String> favorites;
    private int sideFocusId;

    ChannelAdapter(Context context, java.util.Set<String> favorites, Listener listener) {
        this.context = context;
        this.favorites = favorites;
        this.listener = listener;
    }

    void setChannels(List<Channel> values) {
        channels.clear();
        channels.addAll(values);
        notifyDataSetChanged();
    }

    void setSideFocusId(int value) { sideFocusId = value; }

    @Override public int getCount() { return channels.size(); }
    @Override public Channel getItem(int position) { return channels.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        Channel row = getItem(position);
        Holder holder;
        if (convertView == null || !(convertView.getTag() instanceof Holder)) {
            LinearLayout card = new LinearLayout(context);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(8), dp(12), dp(8));
            card.setFocusable(true);
            card.setFocusableInTouchMode(true);
            card.setNextFocusLeftId(sideFocusId);
            card.setBackground(focusBackground());

            TextView number = new TextView(context);
            number.setTextColor(0xFFD8B86F);
            number.setTextSize(14);
            number.setTypeface(null, Typeface.BOLD);
            number.setGravity(Gravity.CENTER);
            card.addView(number, new LinearLayout.LayoutParams(dp(38), -1));

            ImageView logo = new ImageView(context);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            logo.setPadding(dp(5), dp(5), dp(5), dp(5));
            logo.setBackground(round(0xFF263747, 0xFF3B4E60, dp(9)));
            LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(54), dp(46));
            logoLp.leftMargin = dp(10);
            card.addView(logo, logoLp);

            LinearLayout labels = new LinearLayout(context);
            labels.setOrientation(LinearLayout.VERTICAL);
            labels.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams labelsLp = new LinearLayout.LayoutParams(0, -1, 1);
            labelsLp.leftMargin = dp(13);
            card.addView(labels, labelsLp);
            TextView name = new TextView(context);
            name.setTextColor(Color.WHITE);
            name.setTextSize(17);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            labels.addView(name);
            TextView group = new TextView(context);
            group.setTextColor(0xFF95A5B5);
            group.setTextSize(12);
            group.setSingleLine(true);
            LinearLayout.LayoutParams groupLp = new LinearLayout.LayoutParams(-1, -2);
            groupLp.topMargin = dp(2);
            labels.addView(group, groupLp);

            TextView star = new TextView(context);
            star.setTextColor(0xFFE1C47F);
            star.setTextSize(20);
            star.setGravity(Gravity.CENTER);
            card.addView(star, new LinearLayout.LayoutParams(dp(30), -1));
            holder = new Holder(number, logo, name, group, star);
            card.setTag(holder);
            convertView = card;
        } else {
            holder = (Holder) convertView.getTag();
        }
        holder.number.setText(String.format(java.util.Locale.ROOT, "%03d", row.channelNumber));
        holder.name.setText(row.name);
        holder.group.setText(row.groupTitle.isEmpty() ? row.tvgId : row.groupTitle);
        holder.star.setText(favorites.contains(row.id) ? "★" : "");
        convertView.setFocusable(true);
        convertView.setClickable(true);
        convertView.setOnClickListener(view -> listener.onChannelClicked(row));
        holder.logo.setImageDrawable(round(0xFF263747, 0xFF3B4E60, dp(9)));
        holder.logo.setTag(row.logoUrl);
        Bitmap cached = row.logoUrl.isEmpty() ? null : logos.get(row.logoUrl);
        if (cached != null) holder.logo.setImageBitmap(cached);
        else if (!row.logoUrl.isEmpty()) loadLogo(row.logoUrl, holder.logo);
        return convertView;
    }

    private void loadLogo(String address, ImageView target) {
        logoWorker.execute(() -> {
            Bitmap bitmap = logos.get(address);
            if (bitmap == null) {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL(address).openConnection();
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestProperty("User-Agent", "TVNhaPlus/0.1 AndroidTV");
                    try (java.io.InputStream input = connection.getInputStream()) {
                        bitmap = BitmapFactory.decodeStream(input);
                    }
                    if (bitmap != null) logos.put(address, bitmap);
                } catch (Exception ignored) {
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
            Bitmap result = bitmap;
            if (result != null) target.post(() -> {
                if (address.equals(target.getTag())) target.setImageBitmap(result);
            });
        });
    }

    private Drawable focusBackground() {
        android.graphics.drawable.StateListDrawable states = new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused}, round(0xFF26394A, 0xFFE0BC70, dp(12)));
        states.addState(new int[]{android.R.attr.state_pressed}, round(0xFF26394A, 0xFFE0BC70, dp(12)));
        states.addState(new int[]{}, round(0xFF151E28, 0xFF263340, dp(12)));
        return states;
    }

    private GradientDrawable round(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(int value) { return Math.round(value * context.getResources().getDisplayMetrics().density); }

    private static final class Holder {
        final TextView number, name, group, star;
        final ImageView logo;
        Holder(TextView number, ImageView logo, TextView name, TextView group, TextView star) {
            this.number = number; this.logo = logo; this.name = name; this.group = group; this.star = star;
        }
    }
}
