package vn.hoanghoa.tvnhaplus.ui;

import android.content.Context;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import vn.hoanghoa.tvnhaplus.data.Channel;
import vn.hoanghoa.tvnhaplus.data.Playlist;

public final class GuideView extends FrameLayout {
    public interface Listener {
        void onChannelSelected(Channel channel);
        void onFavoriteToggled(Channel channel);
        void onChannelFocused(Channel channel);
        void onChangePlaylist();
        void onAudioOptions();
        void onSubtitleOptions();
    }

    private final Playlist playlist;
    private final Listener listener;
    private final Set<String> favorites;
    private final LinearLayout categories;
    private final ListView channelList;
    private final ChannelAdapter adapter;
    private final TextView count;
    private final TextView selectedName;
    private final TextView selectedGroup;
    private final TextView currentProgramme;
    private final TextView nextProgramme;
    private final ArrayList<Button> categoryButtons = new ArrayList<>();
    private Button searchCategoryButton;
    private Button allCategoryButton;
    private Button sourceActionButton;
    private Button audioActionButton;
    private Button subtitleActionButton;
    private String selectedCategory = "Tất cả kênh";
    private String playingId = "";
    private String searchQuery = "";
    private Map<String, vn.hoanghoa.tvnhaplus.data.XmltvParser.Schedule> schedules = java.util.Collections.emptyMap();

    public GuideView(Context context, Playlist playlist, Set<String> favorites, Listener listener) {
        super(context);
        this.playlist = playlist;
        this.favorites = new java.util.HashSet<>(favorites);
        this.listener = listener;
        setFocusable(true);
        setBackgroundColor(0xF20B1119);

        LinearLayout surface = new LinearLayout(context);
        surface.setOrientation(LinearLayout.VERTICAL);
        surface.setPadding(dp(36), dp(22), dp(36), dp(18));
        addView(surface, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(context);
        header.setGravity(Gravity.CENTER_VERTICAL);
        surface.addView(header, new LinearLayout.LayoutParams(-1, dp(66)));
        LinearLayout titles = new LinearLayout(context);
        titles.setOrientation(LinearLayout.VERTICAL);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView eyebrow = text("TV NHÀ PLUS   /   TV GUIDE", 12, 0xFFD9B76F);
        eyebrow.setLetterSpacing(.11f);
        titles.addView(eyebrow);
        TextView title = text(playlist.name, 26, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(4);
        titles.addView(title, titleLp);
        count = text("", 15, 0xFFB1BECA);
        count.setGravity(Gravity.CENTER);
        count.setPadding(dp(16), 0, dp(16), 0);
        count.setBackground(round(0xFF18232E, 0xFF354554, dp(20)));
        sourceActionButton = new Button(context);
        sourceActionButton.setId(View.generateViewId());
        sourceActionButton.setText("Đổi playlist");
        sourceActionButton.setAllCaps(false);
        sourceActionButton.setTextSize(14);
        sourceActionButton.setPadding(dp(12), 0, dp(12), 0);
        sourceActionButton.setFocusable(true);
        styleHeaderAction(sourceActionButton, false);
        sourceActionButton.setOnFocusChangeListener((v, focused) -> styleHeaderAction(sourceActionButton, focused));
        sourceActionButton.setOnClickListener(v -> listener.onChangePlaylist());
        LinearLayout.LayoutParams sourceLp = new LinearLayout.LayoutParams(-2, dp(40));
        sourceLp.rightMargin = dp(10);
        header.addView(sourceActionButton, sourceLp);
        audioActionButton = new Button(context);
        audioActionButton.setId(View.generateViewId());
        audioActionButton.setText("Âm thanh");
        audioActionButton.setAllCaps(false);
        audioActionButton.setTextSize(14);
        audioActionButton.setPadding(dp(12), 0, dp(12), 0);
        audioActionButton.setFocusable(true);
        styleHeaderAction(audioActionButton, false);
        audioActionButton.setOnFocusChangeListener((v, focused) -> styleHeaderAction(audioActionButton, focused));
        audioActionButton.setOnClickListener(v -> listener.onAudioOptions());
        sourceActionButton.setNextFocusRightId(audioActionButton.getId());
        audioActionButton.setNextFocusLeftId(sourceActionButton.getId());
        int subtitleActionId = View.generateViewId();
        audioActionButton.setNextFocusRightId(subtitleActionId);
        LinearLayout.LayoutParams audioLp = new LinearLayout.LayoutParams(-2, dp(40));
        audioLp.rightMargin = dp(10);
        header.addView(audioActionButton, audioLp);
        subtitleActionButton = new Button(context);
        subtitleActionButton.setId(subtitleActionId);
        subtitleActionButton.setText("Phụ đề");
        subtitleActionButton.setAllCaps(false);
        subtitleActionButton.setTextSize(14);
        subtitleActionButton.setPadding(dp(12), 0, dp(12), 0);
        subtitleActionButton.setFocusable(true);
        styleHeaderAction(subtitleActionButton, false);
        subtitleActionButton.setOnFocusChangeListener((v, focused) -> styleHeaderAction(subtitleActionButton, focused));
        subtitleActionButton.setOnClickListener(v -> listener.onSubtitleOptions());
        subtitleActionButton.setNextFocusLeftId(audioActionButton.getId());
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-2, dp(40));
        subtitleLp.rightMargin = dp(10);
        header.addView(subtitleActionButton, subtitleLp);
        header.addView(count, new LinearLayout.LayoutParams(-2, dp(40)));
        LinearLayout clockBadge = new LinearLayout(context);
        clockBadge.setOrientation(LinearLayout.HORIZONTAL);
        clockBadge.setGravity(Gravity.CENTER);
        clockBadge.setPadding(dp(12), 0, dp(12), 0);
        clockBadge.setBackground(round(0xFF18232E, 0xFF354554, dp(12)));
        clockBadge.setFocusable(false);
        TextView clockIcon = text("◷", 17, 0xFFE0BE73);
        clockBadge.addView(clockIcon, new LinearLayout.LayoutParams(-2, -1));
        TextClock clock = new TextClock(context);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFF0F3F6);
        clock.setTextSize(16);
        clock.setGravity(Gravity.CENTER);
        clock.setContentDescription("Giờ hiện tại");
        LinearLayout.LayoutParams clockTextLp = new LinearLayout.LayoutParams(-2, -1);
        clockTextLp.leftMargin = dp(7);
        clockBadge.addView(clock, clockTextLp);
        LinearLayout.LayoutParams clockLp = new LinearLayout.LayoutParams(-2, dp(40));
        clockLp.leftMargin = dp(10);
        header.addView(clockBadge, clockLp);

        View divider = new View(context);
        divider.setBackgroundColor(0x44384858);
        surface.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout body = new LinearLayout(context);
        body.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(-1, 0, 1);
        bodyLp.topMargin = dp(16);
        bodyLp.bottomMargin = dp(12);
        surface.addView(body, bodyLp);

        ScrollView categoryScroll = new ScrollView(context);
        categoryScroll.setVerticalScrollBarEnabled(false);
        LinearLayout.LayoutParams categoryScrollLp = new LinearLayout.LayoutParams(dp(222), -1);
        categoryScrollLp.rightMargin = dp(20);
        body.addView(categoryScroll, categoryScrollLp);
        categories = new LinearLayout(context);
        categories.setOrientation(LinearLayout.VERTICAL);
        categoryScroll.addView(categories);

        channelList = new ListView(context);
        channelList.setId(View.generateViewId());
        channelList.setDivider(null);
        channelList.setDividerHeight(dp(7));
        channelList.setSelector(android.R.color.transparent);
        channelList.setVerticalScrollBarEnabled(false);
        channelList.setItemsCanFocus(true);
        channelList.setFocusable(true);
        channelList.setFocusableInTouchMode(true);
        channelList.setDescendantFocusability(FOCUS_AFTER_DESCENDANTS);
        adapter = new ChannelAdapter(context, this.favorites, listener::onChannelSelected);
        channelList.setAdapter(adapter);
        channelList.setOnFocusChangeListener((view, hasFocus) -> {
            if (!hasFocus || adapter.getCount() == 0) return;
            int position = channelList.getSelectedItemPosition();
            focusChannelAt(position < 0 ? 0 : position);
        });
        body.addView(channelList, new LinearLayout.LayoutParams(0, -1, 1));

        LinearLayout info = new LinearLayout(context);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(22), dp(20), dp(20), dp(18));
        info.setBackground(round(0xFF141E28, 0xFF2C3C4A, dp(18)));
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(dp(350), -1);
        infoLp.leftMargin = dp(20);
        body.addView(info, infoLp);
        TextView nowEyebrow = text("KÊNH ĐANG CHỌN", 12, 0xFFD9B76F);
        nowEyebrow.setLetterSpacing(.1f);
        info.addView(nowEyebrow);
        selectedName = text("Chọn một kênh", 23, Color.WHITE);
        selectedName.setTypeface(null, Typeface.BOLD);
        selectedName.setMaxLines(2);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, -2);
        nameLp.topMargin = dp(10);
        info.addView(selectedName, nameLp);
        selectedGroup = text("", 14, 0xFF91A0AF);
        LinearLayout.LayoutParams groupLp = new LinearLayout.LayoutParams(-1, -2);
        groupLp.topMargin = dp(5);
        info.addView(selectedGroup, groupLp);
        View infoDivider = new View(context);
        infoDivider.setBackgroundColor(0x44384858);
        LinearLayout.LayoutParams infoDividerLp = new LinearLayout.LayoutParams(-1, dp(1));
        infoDividerLp.topMargin = dp(22);
        infoDividerLp.bottomMargin = dp(20);
        info.addView(infoDivider, infoDividerLp);
        TextView currentLabel = text("ĐANG PHÁT", 12, 0xFF8393A3);
        currentLabel.setLetterSpacing(.1f);
        info.addView(currentLabel);
        currentProgramme = text("Chưa có lịch phát", 16, 0xFFDCE3EA);
        currentProgramme.setMaxLines(3);
        LinearLayout.LayoutParams currentLp = new LinearLayout.LayoutParams(-1, -2);
        currentLp.topMargin = dp(7);
        info.addView(currentProgramme, currentLp);
        TextView nextLabel = text("TIẾP THEO", 12, 0xFF8393A3);
        nextLabel.setLetterSpacing(.1f);
        LinearLayout.LayoutParams nextLabelLp = new LinearLayout.LayoutParams(-1, -2);
        nextLabelLp.topMargin = dp(22);
        info.addView(nextLabel, nextLabelLp);
        nextProgramme = text("Lịch phát sẽ hiện khi playlist có XMLTV", 15, 0xFFAFBBC7);
        nextProgramme.setMaxLines(3);
        LinearLayout.LayoutParams nextLp = new LinearLayout.LayoutParams(-1, -2);
        nextLp.topMargin = dp(7);
        info.addView(nextProgramme, nextLp);

        TextView footer = text("↑↓ Kênh   ·   ←→ Tua 10 giây*   ·   OK Xem   ·   Giữ OK Yêu thích   ·   Back Đóng", 13, 0xFF8694A2);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        surface.addView(footer, new LinearLayout.LayoutParams(-1, dp(30)));

        buildCategories();
        filterChannels();
        channelList.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < adapter.getCount()) showChannel(adapter.getItem(position));
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
    }

    public void show(String currentChannelId) {
        show(currentChannelId, "");
    }

    public void show(String currentChannelId, String categoryName) {
        if (categoryName != null && !categoryName.trim().isEmpty()) {
            String requested = categoryName.trim();
            for (Button button : categoryButtons) {
                String label = button.getText().toString();
                if (label.equalsIgnoreCase(requested) || label.toLowerCase(Locale.ROOT).contains(requested.toLowerCase(Locale.ROOT))) {
                    selectedCategory = label;
                    searchQuery = "";
                    updateCategoryStyles();
                    filterChannels();
                    break;
                }
            }
        }
        playingId = currentChannelId == null ? "" : currentChannelId;
        int selected = 0;
        for (int i = 0; i < adapter.getCount(); i++) if (adapter.getItem(i).id.equals(playingId)) selected = i;
        if (adapter.getCount() > 0) {
            final int selectedPosition = selected;
            showChannel(adapter.getItem(selectedPosition));
            focusChannelAt(selectedPosition);
        } else if (categoryButtons.size() > 0) categoryButtons.get(0).requestFocus();
    }

    public void refreshFavorites(Set<String> values) {
        favorites.clear();
        favorites.addAll(values);
        adapter.notifyDataSetChanged();
        filterChannels();
    }

    public Channel focusedChannel() {
        int position = channelList.getSelectedItemPosition();
        return position >= 0 && position < adapter.getCount() ? adapter.getItem(position) : null;
    }

    public void updateSchedules(Map<String, vn.hoanghoa.tvnhaplus.data.XmltvParser.Schedule> values) {
        schedules = values == null ? java.util.Collections.emptyMap() : values;
        int position = channelList.getSelectedItemPosition();
        if (position >= 0 && position < adapter.getCount()) showChannel(adapter.getItem(position));
    }

    private void buildCategories() {
        categories.removeAllViews();
        categoryButtons.clear();
        LinkedHashSet<String> names = new LinkedHashSet<>();
        names.add("⌕  Tìm kênh");
        names.add("Tất cả kênh");
        names.add("Yêu thích");
        for (Channel channel : playlist.channels) if (!channel.groupTitle.isEmpty()) names.add(channel.groupTitle);
        for (String name : names) {
            Button button = new Button(getContext());
            button.setId(View.generateViewId());
            button.setText(name);
            button.setAllCaps(false);
            button.setTextSize(15);
            button.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            button.setPadding(dp(14), 0, dp(10), 0);
            button.setFocusable(true);
            button.setNextFocusRightId(channelList.getId());
            styleCategoryButton(button, name.equals(selectedCategory), false);
            button.setOnFocusChangeListener((view, focused) ->
                    styleCategoryButton(button, name.equals(selectedCategory), focused));
            button.setOnClickListener(v -> {
                if (name.startsWith("⌕")) { showSearchDialog(); return; }
                selectedCategory = name;
                if (selectedCategory.equals("Tất cả kênh")) searchQuery = "";
                updateCategoryStyles();
                filterChannels();
                if (adapter.getCount() > 0) {
                    int focusedPosition = 0;
                    for (int i = 0; i < adapter.getCount(); i++)
                        if (adapter.getItem(i).id.equals(playingId)) { focusedPosition = i; break; }
                    final int position = focusedPosition;
                    focusChannelAt(position);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
            lp.bottomMargin = dp(6);
            categories.addView(button, lp);
            categoryButtons.add(button);
            if (name.startsWith("⌕")) searchCategoryButton = button;
            if (name.equals("Tất cả kênh")) allCategoryButton = button;
        }
        for (int i = 0; i < categoryButtons.size(); i++) {
            Button button = categoryButtons.get(i);
            if (i > 0) button.setNextFocusUpId(categoryButtons.get(i - 1).getId());
            if (i + 1 < categoryButtons.size()) button.setNextFocusDownId(categoryButtons.get(i + 1).getId());
        }
        if (searchCategoryButton != null && allCategoryButton != null) {
            searchCategoryButton.setNextFocusDownId(allCategoryButton.getId());
            allCategoryButton.setNextFocusUpId(searchCategoryButton.getId());
            searchCategoryButton.setNextFocusUpId(subtitleActionButton.getId());
            subtitleActionButton.setNextFocusDownId(searchCategoryButton.getId());
            channelList.setNextFocusLeftId(allCategoryButton.getId());
            adapter.setSideFocusId(allCategoryButton.getId());
        }
    }

    private void styleHeaderAction(Button button, boolean focused) {
        button.setTextColor(focused ? Color.WHITE : 0xFFDCE3EA);
        button.setTypeface(null, focused ? Typeface.BOLD : Typeface.NORMAL);
        button.setBackground(round(focused ? 0xFF2A4965 : 0xFF18232E,
                focused ? 0xFFB5E0FF : 0xFF354554, dp(12)));
    }

    private void updateCategoryStyles() {
        for (int i = 0; i < categoryButtons.size(); i++) {
            Button button = categoryButtons.get(i);
            boolean active = button.getText().toString().equals(selectedCategory);
            styleCategoryButton(button, active, button.hasFocus());
        }
    }

    private void styleCategoryButton(Button button, boolean active, boolean focused) {
        int fill = active ? (focused ? 0xFF2E5C7C : 0xFF243543)
                : (focused ? 0xFF263B4D : 0x00141E28);
        int stroke = focused ? 0xFFB5E0FF : active ? 0xFF536B7E : 0x00354858;
        button.setTextColor(active || focused ? Color.WHITE : 0xFFABB7C3);
        button.setTypeface(null, focused ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        button.setBackground(round(fill, stroke, dp(10)));
    }

    private void filterChannels() {
        ArrayList<Channel> filtered = new ArrayList<>();
        for (Channel channel : playlist.channels) {
            String query = searchQuery.toLowerCase(Locale.ROOT);
            if (!query.isEmpty() && !channel.name.toLowerCase(Locale.ROOT).contains(query)
                    && !channel.groupTitle.toLowerCase(Locale.ROOT).contains(query)
                    && !channel.tvgId.toLowerCase(Locale.ROOT).contains(query)) continue;
            if (selectedCategory.equals("Yêu thích") && !favorites.contains(channel.id)) continue;
            if (!selectedCategory.equals("Tất cả kênh") && !selectedCategory.equals("Yêu thích")
                    && !selectedCategory.equals(channel.groupTitle)) continue;
            filtered.add(channel);
        }
        adapter.setChannels(filtered);
        count.setText(filtered.size() + " / " + playlist.channels.size() + " kênh");
        if (filtered.isEmpty()) {
            selectedName.setText(selectedCategory.equals("Yêu thích") ? "Chưa có kênh yêu thích" : "Không tìm thấy kênh");
            selectedGroup.setText("");
            currentProgramme.setText("Hãy đổi nhóm hoặc tìm một kênh khác.");
            nextProgramme.setText("");
        }
    }

    private void showChannel(Channel channel) {
        selectedName.setText(channel.name);
        selectedGroup.setText(channel.groupTitle.isEmpty() ? "Kênh " + channel.channelNumber : channel.groupTitle);
        vn.hoanghoa.tvnhaplus.data.XmltvParser.Schedule schedule = schedules.get(channel.tvgId);
        if (schedule != null && schedule.current != null) {
            currentProgramme.setText(time(schedule.current.startMillis) + "  " + schedule.current.title);
            nextProgramme.setText(schedule.next == null ? "Chưa có thông tin tiếp theo" : time(schedule.next.startMillis) + "  " + schedule.next.title);
        } else {
            currentProgramme.setText(channel.id.equals(playingId) ? "Đang phát trên thiết bị này" : "Bấm OK để chuyển sang kênh này");
            nextProgramme.setText("Chưa có lịch phát khớp cho kênh này");
        }
    }

    private void showSearchDialog() {
        EditText input = new EditText(getContext());
        input.setSingleLine(true);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF91A0AF);
        input.setHint("Tên kênh, nhóm hoặc mã TVG");
        input.setTextSize(18);
        input.setText(searchQuery);
        input.setSelectAllOnFocus(true);
        AlertDialog dialog = new AlertDialog.Builder(getContext())
                .setTitle("Tìm kênh")
                .setMessage("Nhập tên kênh hoặc nhóm")
                .setView(input)
                .setNegativeButton("Đóng", (d, w) -> d.dismiss())
                .setPositiveButton("Tìm", (d, w) -> {
                    searchQuery = input.getText().toString().trim();
                    filterChannels();
                    if (adapter.getCount() > 0) focusChannelAt(0);
                    else categories.requestFocus();
                }).create();
        dialog.show();
        input.requestFocus();
    }

    private void focusChannelAt(int position) {
        if (adapter.getCount() == 0) return;
        int safePosition = Math.max(0, Math.min(position, adapter.getCount() - 1));
        showChannel(adapter.getItem(safePosition));
        channelList.setSelection(safePosition);
        channelList.post(() -> channelList.postDelayed(() -> {
            channelList.requestFocus();
            View row = channelList.getChildAt(Math.max(0, safePosition - channelList.getFirstVisiblePosition()));
            if (row != null) {
                row.setFocusableInTouchMode(true);
                row.requestFocus();
            }
        }, 80));
    }

    private String time(long value) {
        return new SimpleDateFormat("HH:mm", new Locale("vi", "VN")).format(new Date(value));
    }

    private TextView text(String value, int size, int color) {
        TextView view = new TextView(getContext());
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }
    private GradientDrawable round(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
