package vn.hoanghoa.tvnhaplus.ui;

import android.content.Context;
import android.graphics.Color;
import android.widget.FrameLayout;
import android.widget.ImageView;

import vn.hoanghoa.tvnhaplus.R;

/** Full-screen TV Nhà Plus artwork shown while a channel is opening. */
public final class LaunchSplashView extends FrameLayout {
    public LaunchSplashView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(2, 12, 36));
        setFocusable(false);
        setClickable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);

        ImageView artwork = new ImageView(context);
        artwork.setImageResource(R.drawable.tv_banner_art);
        artwork.setScaleType(ImageView.ScaleType.FIT_CENTER);
        artwork.setFocusable(false);
        artwork.setClickable(false);
        addView(artwork, new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
    }
}
