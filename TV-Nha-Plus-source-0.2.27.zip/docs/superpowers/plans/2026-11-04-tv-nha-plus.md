# Kế hoạch triển khai TV Nhà Plus

> **Trạng thái:** MVP hoàn tất; APK release thử nghiệm đã cài và kiểm tra trên LEAP-S1.

**Mục tiêu:** Tạo app IPTV Android TV riêng, có Media3 player, nhập M3U, TV Guide/XMLTV và thao tác remote.

**Kiến trúc:** Project Java riêng tại `tv-nha-plus/`, application ID `vn.hoanghoa.tvnhaplus`. `TvNhaPlusApp` giữ một `PlaylistRepository`; đọc/ghi dữ liệu nền. `PlayerActivity` giữ một ExoPlayer; `GuideView` phủ trên player mà không tạo lại phiên phát.

**Công nghệ:** Android SDK 34, minSdk 26, targetSdk 34, JDK 17, Gradle 8.9, Android Gradle Plugin 8.5.2, AndroidX Media3 1.4.1.

**Đặc tả:** `docs/superpowers/specs/2026-11-04-tv-nha-plus-design.md`

## Ràng buộc

- App, package và dữ liệu riêng; không sửa/gỡ app `simple-iptv` (`vn.hoanghoa.simpleiptv`) hoặc launcher.
- Không xóa dữ liệu app cũ; playlist app mới chỉ lưu trong vùng riêng `vn.hoanghoa.tvnhaplus`.
- Hỗ trợ Android API 26+, build bằng SDK 34/JDK 17.
- Một playlist M3U đang hoạt động; Xtream, DRM và header riêng nhà cung cấp để sau.
- Tải mạng, phân tích M3U/XMLTV, đọc và tuần tự hóa dữ liệu chạy ngoài main thread.

---

### Tác vụ 1: Khung app và màn hình mở đầu — Hoàn tất

**Tệp chính:** `settings.gradle`, `build.gradle`, `gradle.properties`, `app/build.gradle`, manifest, `MainActivity.java`, `TvNhaPlusApp.java`, README, drawable/mipmap.

- [x] Tạo Leanback app riêng với package `vn.hoanghoa.tvnhaplus`, tên/icon/banner TV Nhà Plus.
- [x] Tạo trang mở đầu tối ưu màn hình TV, chữ rõ và điều khiển remote.
- [x] Hiện trang đầu trước khi tải playlist nền; tự mở player sau khi đọc kênh cuối.
- [x] Build APK và xác nhận package/version bằng `aapt`.

### Tác vụ 2: M3U và dữ liệu — Hoàn tất

**Tệp chính:** `data/Channel.java`, `data/Playlist.java`, `data/M3uParser.java`, `data/ChannelNumbering.java`, `data/PlaylistRepository.java`.

- [x] Phân tích tên tiếng Việt, URL luồng, logo, nhóm, `tvg-id` và danh sách URL `url-tvg`.
- [x] Tải HTTP/HTTPS có timeout, giới hạn 32 MB và trạng thái lỗi có thể thử lại.
- [x] Đánh số theo thứ tự VTV, trong nước, sự kiện, nhóm khác, quốc tế.
- [x] Lưu playlist JSON nguyên tử; yêu thích/kênh cuối được cập nhật nhanh bằng SharedPreferences và ghi nền.
- [x] Nhập playlist mới `https://tinyurl.com/vmt47`; xác nhận 545 dòng EXTINF, 543 kênh có URL luồng hợp lệ. Link được điền sẵn nhưng chỉ tải sau khi người dùng bấm xác nhận.

### Tác vụ 3: Guide, logo và remote — Hoàn tất

**Tệp chính:** `ui/GuideView.java`, `ui/ChannelAdapter.java`, `PlayerActivity.java`.

- [x] Dựng TV Guide ba vùng: nhóm, danh sách logo/số/tên kênh, lịch phát.
- [x] Thêm lọc nhóm, tìm kênh, yêu thích, trạng thái rỗng và tải logo bất đồng bộ.
- [x] Nối focus D-pad giữa danh sách và nhóm; chip đang focus được tô nền/viền sáng và chữ đậm; nhóm đã chọn vẫn giữ màu riêng. Đã xác nhận di chuyển xuống từ “Tất cả kênh” sang “Yêu thích” trên LEAP-S1.
- [x] Kiểm tra tìm `VTV2`, giữ OK để lưu yêu thích và mở mục yêu thích trên LEAP-S1.

### Tác vụ 4: Media3 player và âm thanh — Hoàn tất

**Tệp chính:** `player/PlayerController.java`, `PlayerActivity.java`, manifest, `app/build.gradle`.

- [x] Dùng một ExoPlayer/PlayerView; khai báo MIME HLS cho `.m3u8` và URL TV360 không có đuôi file; có nút xem/chọn track âm thanh.
- [x] Hiện trạng thái tải/phát và lỗi dễ hiểu; có nút thử lại.
- [x] Guide mở/đóng không tạo lại player; pause khi app xuống nền và resume khi quay lại.
- [x] Phát từ playlist mới tới trạng thái Media3 `ĐANG PHÁT`; SoC AVC báo hỗ trợ 4K, nhưng kênh tên “360 Phim 4K” trong lần thử chỉ đưa khung hình tối đa 1080p, VTV1 đưa 720p; màn hình đang nhận diện max 1920×1080.
- [x] Thêm chọn audio track; xác nhận Sky Sport F1 có track Dolby Digital AC-3 5.1. Thiết lập encoded surround của LEAP-S1 được chuyển sang Auto; HDMI Audio Policy báo AC-3/E-AC-3 đa kênh.

### Tác vụ 5: XMLTV — Hoàn tất

**Tệp chính:** `data/Programme.java`, `data/XmltvParser.java`, `data/EpgRepository.java`, `ui/GuideView.java`.

- [x] Thử nhiều URL trong `url-tvg`, hỗ trợ gzip và giới hạn dữ liệu 64 MB.
- [x] Ghép lịch hiện tại/kế tiếp theo `tvg-id`, cache 30 phút trên nền.
- [x] Xác nhận Guide hiện đúng chương trình và giờ cho kênh VTV trên LEAP-S1.

### Tác vụ 6: Nhập số, khôi phục và đóng gói — Hoàn tất

**Tệp chính:** `PlayerActivity.java`, `PlaylistRepository.java`, `app/build.gradle`, README.

- [x] Nhập số có HUD; xác nhận `009` chuyển sang VTV7.
- [x] Đồng hồ `HH:mm` luôn hiện ở góc trên phải cả TV Guide lẫn màn phát; overlay tín hiệu hiển thị độ phân giải, codec, FPS, bitrate và audio track đang chọn.
- [x] Mở lại app tiếp tục kênh đã xem sau khi force-stop/khởi chạy lại.
- [x] Cài APK release lên LEAP-S1 bằng `adb install -r`; xác nhận version `0.2.9`.
- [x] Xác nhận app cũ vẫn cài với version `0.5.0`; không xóa dữ liệu app cũ.
- [x] Cập nhật README tiếng Việt và lưu ảnh Guide xem trước.

## Giới hạn xác minh

- Chương trình EPG phụ thuộc máy chủ nguồn và việc khớp `tvg-id`.
- Lớp video phần cứng có thể đen trong ảnh chụp ADB; trạng thái phát và việc khởi tạo decoder được xác nhận nhưng ảnh ADB không tự chứng minh đã nhìn thấy frame trên TV.
- Luồng DRM, header/token riêng, codec không hỗ trợ hoặc URL hết hạn có thể không phát.
