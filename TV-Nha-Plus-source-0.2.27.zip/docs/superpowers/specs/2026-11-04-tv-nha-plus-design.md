# TV Nhà Plus — Đặc tả thiết kế

## Mục tiêu
Xây dựng một app IPTV Android TV riêng cho LEAP-S1, giao diện trau chuốt, thao tác bằng remote, có hướng dẫn kênh tương tự TiviMate. App TV Nhà hiện tại và dữ liệu đã lưu phải được giữ nguyên.

## Người dùng và thiết bị
- Người dùng chính là các thành viên trong gia đình, gồm người lớn tuổi dùng remote Android TV.
- Thiết bị mục tiêu là Skyworth Formuler LEAP-S1, Android 14; Android API tối thiểu là 26; build bằng Android SDK 34 và JDK 17.
- Giao diện dùng chữ lớn dễ đọc, trạng thái focus rõ, điều hướng D-pad nhất quán và ít tầng menu.

## Phạm vi sản phẩm
### Bản đầu
- Mã ứng dụng, vùng dữ liệu và thư mục project riêng với `simple-iptv`.
- Phát IPTV toàn màn hình ngay trong app bằng AndroidX Media3 ExoPlayer.
- Nhập một link M3U qua HTTP/HTTPS; đọc tên kênh, URL luồng, logo, nhóm, TVG ID và URL XMLTV của playlist.
- Khi đang phát, bấm OK mở lớp TV Guide. Guide có logo/tên kênh, lọc nhóm và chương trình hiện tại/kế tiếp nếu khớp dữ liệu XMLTV.
- Kênh yêu thích, tìm kiếm, nhập số kênh và chuyển kênh lên/xuống.
- Lưu playlist, yêu thích và kênh cuối trong vùng riêng của app. Mở lại app sẽ vào kênh cuối nếu kênh còn tồn tại.
- Có trạng thái đang tải, danh sách rỗng, playlist lỗi, không có EPG và lỗi phát kèm thử lại/quay lại.

### Để sau
- Xtream Codes, nhiều playlist, xem lại, ghi hình, timeshift, kiểm soát phụ huynh, đồng bộ cloud, card trên launcher/home và mở bằng player bên ngoài.
- Bản đầu không cam kết luồng DRM hoặc yêu cầu header xác thực riêng của nhà cung cấp.

## Tương tác và định hướng hình ảnh
- Giao diện TV nền than/xanh đậm với màu nhấn tiết chế, không lạm dụng gradient, logo và tên kênh rõ ràng.
- Mở app vào màn hình phát. OK mở Guide; Back đóng Guide để về màn phát; phím kênh lên/xuống đổi kênh; phím số hiện HUD và dò kênh sau một khoảng dừng ngắn hoặc đủ ba chữ số.
- Guide có thanh nhóm gọn và khu vực kênh/chương trình. Mục đang focus phải nổi bật rõ và điều khiển được hoàn toàn bằng D-pad.
- Mở/đóng Guide không được làm mất phiên phát hiện tại.

## Kiến trúc
- App Android native viết bằng Java trong project Gradle riêng `tv-nha-plus/`, application ID `vn.hoanghoa.tvnhaplus`.
- AndroidX Media3 ExoPlayer 1.4.1 quản lý phát; Activity/View quản lý focus và bề mặt hiển thị.
- Playlist repository tải và phân tích M3U/XMLTV ngoài main thread, lưu trạng thái kênh/EPG/yêu thích đã chuẩn hóa trong vùng riêng app.
- UI gồm màn hình player, lớp TV Guide, màn nhập playlist và các trạng thái rỗng/lỗi.
- Không sửa launcher, project `simple-iptv` cũ hoặc hợp đồng package/provider của app cũ.

## Chất lượng và tiêu chí nghiệm thu
- Build lặp lại được bằng Android SDK 34 và JDK 17 của workspace khi có dependency cần thiết.
- Playlist thử hợp lệ có thể nhập; logo/nhóm/kênh hiển thị mà không làm nghẽn UI.
- Trên LEAP-S1, D-pad mở/đóng Guide, di chuyển focus, chọn kênh, đổi nhóm và nhập số mà không mất focus.
- ExoPlayer phát được luồng HLS công khai tương thích và giữ phát khi mở Guide; không tự nhập hoặc ghi đè playlist riêng của người dùng.
- Mở lại app khôi phục kênh cuối; luồng thiếu/hết hạn hiển thị lỗi có thể phục hồi.
- Không khẳng định đã xác minh giao diện/thiết bị nếu chưa có bằng chứng kiểm tra thật.
